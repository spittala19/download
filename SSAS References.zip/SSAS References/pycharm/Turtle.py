from turtle import *
import json
bgcolor("black")
speed(-5)
hideturtle()

for i in range(120):
    color("red")
    circle(i)
    color("blue")
    circle(i*0.0)
    right(3)
    forward(3)

done()

