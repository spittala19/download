## Pymongo is the Mongo driver written in Python to connect to a Mongo Server

import pymongo

from pymongo import MongoClient

##cluster = MongoClient("mongodb+srv://Bernard:Kate0805%25@cluster0.erbt3.mongodb.net/myFirstDatabase?retryWrites=true"                      "&w=majority")
client = MongoClient('mongodb://localhost:27017/')
print(client.list_database_names())

db = client["mytest"]   # defining a variable for a database
print(db.list_collection_names())
customers = db["customers"]    # setting a variable for a collection

print(customers.count_documents({}))  # counting number of documents
"""
customers.insert_one({"firstname":"Sai","LastName":"Pitalla"})  # Inserting a record into the database

print(customers.find_one({"firstname":"Sai"}))


"""
"""
family = [
            {
              "firstname":"Albertina"
             ,"firstname":"Tinashe"
             ,"firstname":"Reginald"

           }]

customers.insert_many(family)  # clever way of inserting a list or creating documents from a list
"""
"""
print(customers.find_one({"firstname": "Tinashe"}))  # display record per criteria


for customer in customers.find():  #To display all documents in Python, you have to use the for Loop
    print(customer)

for customer in customers.find().limit(2):  #To display all documents, but only limiting to 2
    print(customer)

for customer in customers.find({},{"firstname":1,"LastName":1,"_id":0}):  #Only display first & last name, no id's, be mindful of the first {}
    print(customer)

for customer in customers.find({"Age":47},{"Age":1,"firstname":1,"LastName":1,"_id":0}):  # Display selected records with an Age filter
    print(customer)

for customer in customers.find({"firstname":{"$regex":"^A"}},{"Age":1,"firstname":1,"LastName":1,"_id":0}):  # Display Documents with firstname starting with A with an Age filter
    print(customer)

# Updating Many Documents, like the idea of creating variables first
myquery = {"firstname":{"$regex":"^D"}}  # condition
newvalues = {"$set":{"firstname":"Sai"}} # set to update to

result = customers.update_many(myquery,newvalues) # clean way of updating using variables

for customer in customers.find({},{"firstname":1}): #find the updated record(s) by displaying firstname only
    print(customer)

"""

"""

for r in range(1,11,3):
    print(r)

r = 1
while r <= 10:
    print(r)
    r+=3
    print("End of the Loop")


cluster = pymongo.MongoClient()  ## connecting to a local Mongo instance

db = cluster["mytest"]

collection = db["customers"]

## Creating a record
## post = {"firstname": "Alex", "Lastname": "Jones","Age": 47}

##collection.insert_one(post)

## List all databases
print(cluster.list_database_names())

## List all collections
print(db.list_collection_names())

## Reading documents in a collection
## mycollection = db["customers"]

for x in collection.find({"age": {"$gte": 3}}):
    print(x)
"""