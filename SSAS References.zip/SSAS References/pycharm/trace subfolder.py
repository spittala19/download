import os
from os import listdir

SearchTerm = "sharad"
ReplaceTerm = "robert"
RootFolderLocation = "C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\"
FileExt = ".dtsConfig"

def DataReplacer(FileFullPath):
    #Open File in Memory
    with open(FileFullPath,'r') as fr:
        FileContent = fr.read()
        FileContent = FileContent.replace(SearchTerm, ReplaceTerm)
    #replace above memory content to the original file
    with open(FileFullPath,'w') as fw:
        fw.write(FileContent)

def FileLister(RootFolderLocation):
    #List of all root files and subfolders
    FileAndSubFolderList = os.listdir(RootFolderLocation)
    for FileName in FileAndSubFolderList:
        #prepare full file path
        FileFullPath =  os.path.join(RootFolderLocation ,FileName)
        #if the filefullpath is subfolder, traverse through it
        if os.path.isdir(FileFullPath):
            #recall this function to traverse through subfolder
            FileListTemp = FileLister(FileFullPath)
            if os.path.isdir(FileFullPath):
                print ('Sub Directory')
            else:
                if FileFullPath.endswith(FileExt):
                    DataReplacer(FileFullPath)
                    print ("File modifed :" + FileFullPath)
                else:
                    print('Different Extension so File Not modifed '+ FileFullPath)
        else :
            if FileFullPath.endswith(FileExt):
                DataReplacer(FileFullPath)
                print ("File modifed  :" + FileFullPath)
            else:
                print('Different Extension so File Not modifed '+ FileFullPath)

def main ():
    FileLister(RootFolderLocation)

if __name__ == "__main__":
    main()

