import pyodbc, pyspark
from pyspark.python.pyspark.shell import spark

connectionstring = "jdbc:sqlserver://origrptprod.f664dfbfa6b3.database.windows.net:1433;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.f664dfbfa6b3.database.windows.net;loginTimeout=30;Authentication=ActiveDirectoryIntegrated;"

df = spark.read.jdbc(connectionstring,"[ReportServerTempDB].[dbo].[tbl_TestMVP]")