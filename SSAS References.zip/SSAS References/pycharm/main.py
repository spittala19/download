# This is a sample Python script.
"""
# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
print(__name__ == '__name__')

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
"""

#i = "Pukar & Richar You Rock"
from math import floor

 file_location = "C:\Users\bmutyanda\NEW_MISC2\MISC\CUMULUS\test.txt"  # make sure slashes are forward slashes not back slashes
 employee_file = open(file_location, "r")  # "r" for read
 # print(employee_file.read())
 print(employee_file.readable())  # evaluating whether the file is readable, it's a boolean
 for employee in employee_file.readlines():  # readlines reads all the lines, and puts them in an array
  print(employee)  # read will simply read the entire file

 employee_file.close()
 
with open(file_location, "r") as F:
print(F.read())
 """
 try:
    Answer = 10/1
    Number = int(input("Enter a number only: "))
    print(Number)
except ZeroDivisionError as err:
 print(err)
 
 
# GETTING_INPUT_FROM_USERS = "INPUT"
def say_hi(name,joiner,age):
   ## print (zita + " is "+age)
    print("{}{}{}".format(name,joiner,age))
say_hi("Bernard"," is ","45")
#print("{} {} {}".format(zita,joiner, age)) #preffered way of contacting

i = 2  # max recognitions

while i <= 3 :
    print("Thanks Demetrius for recognition")
    print("Thanks Balaji for the recognition")
    i += 2
print("")
print("Bernard now close the Recognition")

from math import floor

print(3**4) ## 3 exponent 4 (3 to the power of 4)
print((pow(3,4)))  # another way of 3 exponent 4
print(pow(3,4))
"""