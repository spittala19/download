# CREATING CLASSES FOR INHERITANCE
from pathlib import Path
import os
import fnmatch


# Sample call:
class SearchFileDirectory:
    def __init__(self, directory_location, write_file_location, file_type):
        self.path = Path(directory_location)
        self.list_of_files = os.listdir(self.path)

        pattern = file_type

        with open(write_file_location, "w") as self.write_to_file:
            for entry in self.list_of_files:
                if fnmatch.fnmatch(entry, file_type):
                    self.write_to_file.write(entry + "       is in Folder Name:   " + directory_location + os.linesep)

"""
# Inheriting from a class(es) CREATED ABOVE

from Class_DIR_Navigation import SearchFileDirectory  # means from the Class_DIR_Navigation file import the SearchFileDirectory & Student class

# class SearchFileDirectory:
Search1 = SearchFileDirectory("C:/Projects & Architecture/Enterprise Architecture/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles.txt","*.json*")
Search2 = SearchFileDirectory("C:/Projects & Architecture/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles2.txt","*.pptx")
Search3 = SearchFileDirectory("C:/Projects & Architecture/Enterprise Architecture/Python/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles3.txt","*.*")

Find_Files("C:/Projects & Architecture/Enterprise Architecture/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles.txt","*.txt")

"""
