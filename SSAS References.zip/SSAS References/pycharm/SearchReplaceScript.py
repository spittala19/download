from SearchAndReplaceString import SearchStringAndReplace

#print('Different Extension so File Not modified '+ FileFullPath)
#print("{}{}".format('Different Extension so File Not modified ', 'in Bernard Folder'))

search1 = SearchStringAndReplace("Metrics", "CumulusFinal", "C:/Users/bmutyanda/NEW_MISC2/MISC/CUMULUS/Write/", "*.txt")

