from SearchAndReplaceString import SearchStringAndReplace

class SearchStringAndReplace:

    def __init__(self,SearchTerm,ReplaceTerm,RootFolderLocation ,FileExt):

        self.Se

SearchTerm = "Cumulus"
ReplaceTerm = "CumulusFinal"
RootFolderLocation = "C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\Write\\"
FileExt = ".txt"



def main ():
    FileLister(RootFolderLocation)

if __name__ == "__main__":
    main()

