import os
from os import listdir

class SearchStringAndReplace:


    def __init__(self, SearchTerm, ReplaceTerm, RootFolderLocation, FileExt):
        self.SearchTerm = SearchTerm
        self.ReplaceTerm = ReplaceTerm
        self.RootFolderLocation = RootFolderLocation
        self.FileExt = FileExt
"""
SearchTerm = "CumulusFinal"
ReplaceTerm = "Metrics"
RootFolderLocation = "C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\Write\\"
FileExt = ".txt"
"""


def DataReplacer(self,FileFullPath):
        #Open File in Memory
        with open(FileFullPath,'r') as fr:
            FileContent = fr.read()
            FileContent = FileContent.replace(self.SearchTerm, self.ReplaceTerm)
        #replace above memory content to the original file
        with open(FileFullPath,'w') as fw:
            fw.write(FileContent)

def FileLister(self, RootFolderLocation):
        #List of all root files and subfolders
        FileAndSubFolderList = os.listdir(self.RootFolderLocation)
        for FileName in FileAndSubFolderList:
            #prepare full file path
            FileFullPath =  os.path.join(self.RootFolderLocation ,FileName)
            #if the filefullpath is subfolder, traverse through it
            if os.path.isdir(FileFullPath):
                #recall this function to traverse through subfolder
                FileListTemp = FileLister(FileFullPath)
                if os.path.isdir(FileFullPath):
                    print ('Sub Directory')
                else:
                    if FileFullPath.endswith(self.FileExt):
                        DataReplacer(FileFullPath)
                        print ("File modifed :" + FileFullPath)
                    else:
                        print('Different Extension so File Not modifed '+ FileFullPath)
            else :
                if FileFullPath.endswith(self.FileExt):
                    DataReplacer(FileFullPath)
                    print ("File modifed  :" + FileFullPath)
                else:
                    print('Different Extension so File Not modifed '+ FileFullPath)

def main (self):
        FileLister(self.RootFolderLocation)

if __name__ == "__main__":
    main()


