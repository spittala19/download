import openpyxl
import pyodbc
from datetime import  datetime,timedelta
import concurrent.futures
from threading import Thread
from multiprocessing import Process
import os
import sqlite3 as sl
import shutil
import pandas as pd

jdbcHostname = 'CRHRKSQLPRD01'
jdbcDatabase = 'MRC'
jdbcPort = 1433
pyodbcUrl="DRIVER={ODBC Driver 17 for SQL Server};SERVER="+jdbcHostname+";DATABASE="+jdbcDatabase+";Trusted_Connection=yes"
conn = pyodbc.connect(pyodbcUrl)


error_file = r'Desktop\RATESHEET\RATESHEET\Template\Error.xlsx'
excelSourceDel = r'Desktop\RATESHEET\RATESHEET\Template\Ratesheet Template - Del.xlsx'
excelSourceND = r'Desktop\RATESHEET\RATESHEET\Template\Ratesheet Template - ND.xlsx'
excelTarget=r'Desktop\RATESHEET\RATESHEET\output'
sqliteDBpath= r'Desktop\RATESHEET\RATESHEET\my-test.db'


Indextbl_Query = "select Element ,Value from [MRC].[dbo].[RateSheetIndexTestTable] (nolock) where Element in ('SOFR30A Index','1yr CMT') order by Element"
Index_tbl = conn.execute(Indextbl_Query).fetchall()
OneyrCmt = Index_tbl[0][1]
SOFR30AIndex = Index_tbl[1][1]






class RateSheet():
    def __init__(self,RSID,template_opt,filename,ratesheet,folder):
        self.RSID = RSID
        self.filename = filename
        self.ratesheet = ratesheet
        self.folder  = folder
        
        self.theFile =  self.excelReader(template_opt)
       
        self.dataJSON = self.flatfile()
    
        arr= []
        with concurrent.futures.ThreadPoolExecutor() as executor:
            t1 = executor.submit(self.flatfile)
            t2 = executor.submit(self.coverUpdate)
            t3 = executor.submit(self.govenmentproductsUpdate)
            t4 = executor.submit(self.conventionalproductsUpdate)
            t5 = executor.submit(self.governmentpriceadj)
            t6 = executor.submit(self.fannieMacPriceadj)
            t7 = executor.submit(self.freddieMacPriceadj)

            arr.extend([t1,t2,t3,t4,t5,t6,t7])
            for f in concurrent.futures.as_completed(arr):
                continue
        
        self.savefile()

    def __del__(self):
        # self.con.execute('delete from RateSheetTestTable  where RSID  = ?',(self.RSID,))
        # self.con.commit()
       
        print ('RateSheet instance deleted' + str(self.RSID))

        
    def Exceptionwrite(self,Error):
        try:                       
            theErrorFile = openpyxl.load_workbook(error_file,data_only=True)
            currentsheet = theErrorFile['Error while Creating']
            currentsheet.append([datetime.now(),Error])
            theErrorFile.save(error_file)
            
        except Exception as e:
            pass

    def excelReader(self,template):
        try:
            #print('excel reader called')
            if(template == 'Delegated'):            
                theFile = openpyxl.load_workbook(excelSourceDel,data_only=True)
            if(template == 'NonDelegated'):            
                theFile = openpyxl.load_workbook(excelSourceND,data_only=True)
            return theFile
        except Exception as e:
            self.Exceptionwrite('Error in coverUpdate '+str(e))
                        
    def flatfile(self):
        #print('flatfile called')
    
        def checkKey(dict, key):    
            if key in dict.keys():
                return True
            else:
                return False
        
        try: 
            currentsheet = self.theFile['Flat File']
            currentsheet.delete_rows(2,currentsheet.max_row)
            dataJSON  = {}

            self.con = sl.connect(sqliteDBpath)
            data = self.con.execute('select [FILE NAME],[PROGRAM],DESCRIPTION, RATE,[7-Day],[15-Day],[30-Day],[45-Day],[60-Day],[75-Day],[90-Day],[PRICING DATE],[Day ACTIVITY] from RateSheetTestTable  where RSID  = ?',(self.RSID,)).fetchall()
            self.con.close()
            #self.con.execute('delete from RateSheetTestTable  where RSID  = ?',(self.RSID,)).fetchall()
            
            for row in data:
                row_to_list = [elem for elem in row]
                
                if(not checkKey(dataJSON,row_to_list[2])):
                    dataJSON[row_to_list[2]] = {}
                
                if( not checkKey(dataJSON[row_to_list[2]],row_to_list[3])):
                    dataJSON[row_to_list[2]][ row_to_list[3]] =  row_to_list[6] 
            
                currentsheet.append(row_to_list)        
            return dataJSON
        except Exception as e:
            self.Exceptionwrite('Error in Flatfile Update '+str(e))
            
    def savefile(self):
        try:
            counter = 1
            directory = excelTarget +'/' + self.folder
            if not os.path.exists(directory): os.makedirs(directory)
            
            excelPath = directory + '/' + self.filename+" "+datetime.utcnow().strftime("%m")+"-"+datetime.utcnow().strftime("%d")+"-"+datetime.utcnow().strftime("%Y")+'.xlsx'
            
            
            if not os.path.exists(excelPath):
                self.theFile.save(excelPath)
            else:
                while os.path.exists(excelPath):                  
                    excelPath = directory + '/' + self.filename+" "+datetime.utcnow().strftime("%m")+"-"+datetime.utcnow().strftime("%d")+"-"+datetime.utcnow().strftime("%Y")+ "_" + str(counter)+  '.xlsx'
                    counter += 1
                self.theFile.save(excelPath)
        
        except Exception as e:
            self.Exceptionwrite('Error in Save  '+str(e))
           
    def coverUpdate(self):
        try:
            #print('cover called')
            currentSheet = self.theFile['Cover']  
            currentSheet['B11'].value = self.filename
        except Exception as e:
            self.Exceptionwrite('Error in Cover Update '+str(e))
                          
    def governmentpriceadj(self):
        try:
            #print('governmentpriceadj called')
            currentSheet = self.theFile['Government Price Adj.']  
            currentSheet['B3'].value = self.filename
            currentSheet['N7'].value ="#" + str(self.ratesheet)
            currentSheet['Q7'].value = datetime.utcnow().strftime("%m/%d/%Y %H:%M:%S") +" CDT"
            currentSheet['J37'].value = OneyrCmt 
            currentSheet['J68'].value = OneyrCmt
            
        except Exception as e:
            self.Exceptionwrite('Error in governmentpriceadj Update '+str(e))
            
    def freddieMacPriceadj(self):
        try:
            #print('freddieMacPriceadj called')
            currentSheet = self.theFile['Freddie Mac Price Adj.']  
            currentSheet['B3'].value = self.filename
            currentSheet['L7'].value = "#" + str(self.ratesheet)
            currentSheet['P7'].value = datetime.utcnow().strftime("%m/%d/%Y %H:%M:%S") +" CDT"
            currentSheet['J41'].value = SOFR30AIndex
        except Exception as e:
            self.Exceptionwrite('Error in freddieMacPriceadj Update '+str(e))
                      
    def fannieMacPriceadj(self):
        try:
            #print('fannieMacPriceadj called')
            currentSheet = self.theFile['Fannie Mae Price Adj.']  
            currentSheet['B3'].value = self.filename
            currentSheet['L7'].value ="#" +  str(self.ratesheet)
            currentSheet['P7'].value = datetime.utcnow().strftime("%m/%d/%Y %H:%M:%S")  +" CDT"
            currentSheet['J40'].value = SOFR30AIndex
        except Exception as e:
            self.Exceptionwrite('Error in fannieMacPriceadj Update '+str(e))
                  
    def govenmentproductsUpdate(self):
        try:
            #print('govenmentproductsUpdate called')
            currentSheet = self.theFile['Government Products']  
            currentSheet['B3'].value = self.filename
            currentSheet['K7'].value = '#' + str(self.ratesheet)
            currentSheet['N7'].value = datetime.utcnow().strftime("%m/%d/%Y %H:%M:%S") +" CDT"
            currentSheet['H12'].value = (datetime.utcnow() + timedelta(days=7)).strftime("%m/%d/%Y")
            currentSheet['J12'].value = (datetime.utcnow() + timedelta(days=15)).strftime("%m/%d/%Y")
            currentSheet['L12'].value = (datetime.utcnow() + timedelta(days=30)).strftime("%m/%d/%Y")
            currentSheet['N12'].value = (datetime.utcnow() + timedelta(days=45)).strftime("%m/%d/%Y")
            currentSheet['P12'].value = (datetime.utcnow() + timedelta(days=60)).strftime("%m/%d/%Y")
            currentSheet['R12'].value = (datetime.utcnow() + timedelta(days=75)).strftime("%m/%d/%Y")
            currentSheet['T12'].value = (datetime.utcnow() + timedelta(days=90)).strftime("%m/%d/%Y")
            currentSheet['V12'].value = (datetime.utcnow() + timedelta(days=120)).strftime("%m/%d/%Y")
        
            RSgrids = ['FHA STANDARD 30 YR PRODUCT','OTHER FHA STANDARD PRODUCTS','FHA SPECIALTY PRODUCTS','FHA ARM PRODUCTS','VA STANDARD 30 YR PRODUCT','OTHER VA STANDARD PRODUCTS',
                    'VA SPECIALTY PRODUCTS','VA ARM PRODUCTS','USDA STANDARD 30 YR PRODUCT']
                
            RSgridsrowlines = []
            for RSgrid in RSgrids:
                i=0
                for row in currentSheet.iter_rows(min_row=1,values_only = True):
                    i+=1
                    if(RSgrid in row):  RSgridsrowlines.append(i); break
            RSgridsrowlines.append(currentSheet.max_row+1)                     
            # print(RSgridsrowlines)
            
            
            
            for line in range(0,len(RSgridsrowlines)-1):
                # threadlist = []
                for row in range(RSgridsrowlines[line]+2,RSgridsrowlines[line+1]):
                    MOXICODE = currentSheet.cell(row,4).value
                    if(MOXICODE == None):break
                    # print(MOXICODE)
                    
                    for column in range(5,currentSheet.max_column+1):
                        rate = currentSheet.cell(RSgridsrowlines[line]+1,column).value
                        if(rate == None):break
                        currentSheet.cell(row,column).value  =  self.dataJSON.get(MOXICODE).get(rate)
                                            
        except Exception as e:
            self.Exceptionwrite('Error in gvt product Update '+str(e))
                 
    def conventionalproductsUpdate(self):
        try:
            #print('conventional products called')
            currentSheet = self.theFile['Conventional Products'] 
            
            currentSheet['B3'].value = self.filename
            currentSheet['K7'].value = '#' + str(self.ratesheet)
            currentSheet['N7'].value = datetime.utcnow().strftime("%m/%d/%Y %H:%M:%S") +" CDT"
            currentSheet['H12'].value = (datetime.utcnow() + timedelta(days=7)).strftime("%m/%d/%Y")
            currentSheet['J12'].value = (datetime.utcnow() + timedelta(days=15)).strftime("%m/%d/%Y")
            currentSheet['L12'].value = (datetime.utcnow() + timedelta(days=30)).strftime("%m/%d/%Y")
            currentSheet['N12'].value = (datetime.utcnow() + timedelta(days=45)).strftime("%m/%d/%Y")
            currentSheet['P12'].value = (datetime.utcnow() + timedelta(days=60)).strftime("%m/%d/%Y")
            currentSheet['R12'].value = (datetime.utcnow() + timedelta(days=75)).strftime("%m/%d/%Y")
            currentSheet['T12'].value = (datetime.utcnow() + timedelta(days=90)).strftime("%m/%d/%Y")
            currentSheet['V12'].value = (datetime.utcnow() + timedelta(days=120)).strftime("%m/%d/%Y")
            
            RSgrids =  ['FREDDIE MAC 30 YR PRODUCT','OTHER FREDDIE MAC PRODUCTS','FREDDIE MAC HOME POSSIBLE PRODUCTS','FANNIE MAE 30 YR PRODUCT','OTHER FANNIE MAE PRODUCTS','FANNIE MAE HOME READY PRODUCTS','FANNIE MAE ARM PRODUCTS']
                    
            RSgridsrowlines = []
            for RSgrid in RSgrids:
                i=0
                for row in currentSheet.iter_rows(min_row=1,values_only = True):
                    i+=1
                    if(RSgrid in row):  RSgridsrowlines.append(i); break
            RSgridsrowlines.append(currentSheet.max_row)
            
            # print(RSgridsrowlines)
                
            for line in range(0,len(RSgridsrowlines)-1):

                for row in range(RSgridsrowlines[line]+2,RSgridsrowlines[line+1]):
                    MOXICODE = currentSheet.cell(row,4).value
                    if(MOXICODE == None):break
                    # print(MOXICODE)
                    
                    for column in range(5,currentSheet.max_column+1):
                        rate = currentSheet.cell(RSgridsrowlines[line]+1,column).value
                        if(rate == None):break  
                        currentSheet.cell(row,column).value = self.dataJSON.get(MOXICODE).get(rate)
                                
        except Exception as e:
            self.Exceptionwrite('Error in Conventional Products Update '+str(e))
            

if __name__=='__main__':
    
    print(os.path)
    
    if os.path.exists(excelTarget):
        #shutil.rmtree('Desktop\RATESHEET\RATESHEET\output')
        print('rmd')
    else:
        print('pass')
        pass

    start = datetime.now()
    sql='select  distinct RSID from RateSheetTestTable '
    con = sl.connect(sqliteDBpath)
    RSIDs = con.execute(sql,).fetchall()
    list_threads = []
    i=0
    for RSID in RSIDs:
        i+=1
        print(RSID[0])
        id = RSID[0]
        Result = con.execute('select  distinct Delegation,  [file name],[Day Activity],Company from RateSheetTestTable where RSID = ?',(id,)).fetchall()
       
        t  = Process(target=RateSheet, args= (RSID[0],Result[0][0],Result[0][1],Result[0][2],Result[0][3],) )
        list_threads.append(t)
        t.start()
        
        if(i%  100 == 0):
            for t in list_threads: t.join()
            list_threads = []
        
    for t in list_threads: t.join()
    print('fully completed')

    end = datetime.now()
    print (end-start)


