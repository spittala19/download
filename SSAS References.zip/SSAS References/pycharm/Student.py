class Student:

    def __init__(self, name, gpa, major, is_on_probation):     # initializing the class
        self.name = name    # Don't include commas to delimit Self Statements
        self.gpa = gpa
        self.major = major
        self.is_on_probation = is_on_probation


    def on_honor_roll(self):   # This is an objection function
        if self.gpa > 3.0:
            return (True)
        else:
            return (False)

#Unlike Java & C++ where a code block is denoted by curly braces{}, Python uses the INDENTATION to denote a code block


#sample call:
"""
from Student import Student

Student1 = Student('Bernard', 3.5, 'Computer', False)
Student2 = Student('Alex', 2.75,'Business', True)
print(Student1.major)
print(Student2.on_honor_roll())

"""
