import pyodbc
from datetime import  datetime
import  os
from azure.storage.blob import BlockBlobService, PublicAccess
import shutil
import pysftp
import openpyxl

jdbcHostname = 'CRHRKSQLPRD01'
jdbcDatabase = 'MRC'
jdbcPort = 1433
pyodbcUrl="DRIVER={ODBC Driver 17 for SQL Server};SERVER="+jdbcHostname+";DATABASE="+jdbcDatabase+";Trusted_Connection=yes"

block_blob_service = BlockBlobService(account_name='capmarketsdevd58bb59a', account_key='j7+eg9enxS3+TWKHHoLZFvzXp3b0HOMwM5NZzWsD6eLvlsPctl0pSSrNbjgOuETxugH28f3wdxkK4m7sJKJrGg==')

host = "B2BFGINT.MRCOOPER.COM"                    
username = "svc_tldnpftpuser"               
password = "3t@7ilfbv#ywtd" 


error_file = r'Desktop\RATESHEET\RATESHEET\Template\Error.xlsx'

today = datetime.utcnow().strftime("%m")+"-"+datetime.utcnow().strftime("%d")+"-"+datetime.utcnow().strftime("%Y")

class Movement():

    def __init__(self):
       self.source = r'C:\Users\as32\Desktop\RATESHEET\RATESHEET\output'
       self.target = r'C:\Users\as32\Desktop\RATESHEET\RATESHEET\output1'
       connection = pyodbc.connect(pyodbcUrl)
       conn = connection.cursor()
       self.result =   conn.execute('select * from 	[MRC].[dbo].[RateSheetPriceEngineTestTable] (nolock)').fetchall()
    
    def __del__(self):
        pass
    
    def Exceptionwrite(self,Error):
        try:
            theErrorFile = openpyxl.load_workbook(error_file,data_only=True)
            currentsheet = theErrorFile['Error while Moving']
            currentsheet.append([datetime.now(),Error])
            theErrorFile.save(error_file)
        except Exception as e:
            pass
    
    def blob_file_name_creater(self,filename):
            path = datetime.now().strftime("%Y%m%d") +str("_py") +"/"+str(filename)
            return path
    
    def Rsharemove(self):
        
        if not os.path.exists(self.target):
            os.makedirs( self.target)
                                      
        for root, dirs, files in os.walk(self.source):
            if not os.path.exists( os.path.join(self.target, os.path.basename(root))) and os.path.exists( os.path.join(self.source, os.path.basename(root)))  :
                os.makedirs( os.path.join(self.target, os.path.basename(root)))
                
            elif  os.path.exists( os.path.join(self.target, os.path.basename(root))) and os.path.exists( os.path.join(self.source, os.path.basename(root))) :
                shutil.rmtree( os.path.join(self.target, os.path.basename(root)))
                os.makedirs( os.path.join(self.target, os.path.basename(root)))               
            
            
            for filename in files:  
                try:          
                    old_name = os.path.join( os.path.abspath(root), filename )               
                    base, extension = os.path.splitext(filename)
                    new_name = os.path.join(self.target, os.path.basename(root), base.replace(today,'')+extension)            
                   
                    if today in filename:                      
                        shutil.copy(old_name, new_name)
                except Exception as e:
                        self.Exceptionwrite("Error in path :"+str(old_name) +" " + str(e))
                    
                   
    def RsharePriceEngineMove(self):
        for row in self.result:
            sourcepath = os.path.join(self.source,row[1]) 
            targetpath = os.path.join(self.target ,row[0]) 
            
           
            if(os.path.exists(sourcepath)):
               
                if(not os.path.exists(targetpath)):                    
                    os.makedirs(targetpath)
                else:
                    shutil.rmtree(targetpath)
                    os.makedirs(targetpath)
                    
                for filename in os.listdir(sourcepath):
                    try:
                        if(today in filename):
                            base, extension = os.path.splitext(filename)                       
                            shutil.copy(os.path.join(sourcepath, filename ), os.path.join(targetpath,  base.replace(today,'')+extension ))
                    except Exception as e:
                            self.Exceptionwrite("Error in path :"+str(os.path.join(sourcepath, filename )) +" " + str(e))
                        
                        
    def RsharetoCloud(self):
        
        for path, subdirs, files in os.walk(self.target):
            for filename in files:
                try:
                          
                    fullpath = os.path.join(path, filename)   
                    foldername = path.replace(self.target,"") 

                    if(path[-5:].isdigit()):
                        container_name = path[-5:]
                        if(not block_blob_service.exists(container_name)):block_blob_service.create_container(container_name)
                        blob_file_name = self.blob_file_name_creater(filename) 
                        block_blob_service.create_blob_from_path(container_name, blob_file_name, fullpath)               
                        
                        
                    elif('Non-Del' in foldername):
                        container_name = path[-13:-8]
                        if(not block_blob_service.exists(container_name)):block_blob_service.create_container(container_name)
                        blob_file_name = self.blob_file_name_creater(filename)
                        block_blob_service.create_blob_from_path(container_name, blob_file_name, fullpath)
                    else:
                        container_name = 'price-engine'
                        blob_file_name = foldername.replace('\\','')+"/"+str(filename)
                        block_blob_service.create_blob_from_path(container_name, blob_file_name, fullpath)
                        
                    #print (filename ,"\n",foldername,"\n",container_name ,"\n",blob_file_name_creater(filename) )
                    
                    
                except Exception as e:
                    print (filename ,"\n",foldername,"\n",container_name ,"\n",self.blob_file_name_creater(filename) )
                    print(str(e))
                    self.Exceptionwrite('Error in Moving to cloud  '+ str(fullpath) + str(e))
                   
    def RsharetoSFTP(self):
        try:
            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = None
            
            with pysftp.Connection('b2bfgint.mrcooper.com', username='svc_tldnpftpuser', password='3t@7ilfbv#ywtd', private_key=".ppk", cnopts=cnopts) as sftp:
                with sftp.cd('/Vylla_Test/To_MrCooper/Title'):
                    sftp.put(r'C:\Users\as32\Desktop\RATESHEET\RATESHEET\output1\1ST COLONIAL COMMUNITY BANK 10117\MRC-Corr-10117.xlsx')
        except Exception as e:
            print('error exception called')
            print(e)
     

if __name__=='__main__':

    print (datetime.now())  
    M = Movement()
    # M.Rsharemove()
    # print('Rshare Move done')
    # M.RsharePriceEngineMove()
    # print('Price Engine Move done')
    M.RsharetoCloud()
    M.RsharetoSFTP()
    print (datetime.now())

