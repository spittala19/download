from math import *
import os

"""
print("Hello World")
print("    .")
print("   /|")
print("  / |")
print(" /  |")
print("/___|")

Character_name = "Noel"
Character_age = "84"
is_male = True
print("There was once a man called " + Character_name)
print("He was "+ Character_age)

print("girraffe\nworld")
print("girraffe\"world")
print("girraffe\world")


BELOW_STRINGFUNCTIONS = "STRING FUNCTIONS"

phrase = "girraffe world"
print(phrase)
print(phrase + " is cool")
print(phrase.upper())
print(phrase.islower())
print(len(phrase))
print(phrase[0])
print(phrase.index("f"))
print(phrase.replace("girraffe","elephant"))

print(phrase + "\nnhaika")
print(phrase + os.linesep + "testing_lineSeparation")
print(phrase[12])
print(phrase.index(" "))
print(phrase.replace("world","MDCA"))

print("hey".upper().islower())

BELOW_VALUE_FUNCTIONS = "NUMBERS"
print(-2)
print(10%3)
my_num = -7
print(my_num)
print(my_num.__mul__(5))
print("The age of the man is " + str(my_num))
print(my_num.__abs__())
print(my_num.__pow__(2))
print(pow(7, 2))
print(min(my_num, 9))
print(max(my_num, 9))

n = -4
print(my_num.__mul__(n))

print(n.__mul__(-8))

my_num = 3
print(my_num.__round__(3))
print(round(my_num, 3))
print(ceil(my_num))
my_num = 25
print(floor(sqrt(my_num)))

test = 4.5634
print(round(4.5))
print(test.__round__(3))


# GETTING_INPUT_FROM_USERS = "INPUT"
name = input("Enter Your Name Please: ")
age = input("Enter Your Age: ")
print("Hello "+ name + "! You are " + age)


zita = input("zita rako ndiani: ")
joiner = "is"
age = input("age :")
## print (zita + " is "+age)
print("{} {} {}".format(zita,joiner, age)) #preffered way of contacting


print ("{}{}{}{}".format("zita"," rako"," ndiyani"," iwewe")) # concatenating string with no variables


BUILDING_A_CALCULATOR = "CALCULATOR"
num1 = input("Enter a number: ")
num2 = input("Enter another number: ")

print("num1 + num2 = " + str(float(num1)+float(num2)))

MAD_LIBS_GAME = "GAME APP"
color = input("Enter a color :")
flower = input("Enter a flower Name: ")
celebrity = input("Enter a celebrity name: ")

print("Rose are "+ color)
print(flower + " are blue")
print("I Love " + celebrity)

"""

"""
#LISTS 

friends = ["Bernard", "George", "Sam","Jones","Rita"]

print(friends[0])
print(friends[2])
print(friends[-1])  # start indexing at the last position
print(friends[1:])  # this will start at index 1 or second position going all the way
print(friends[0:3]) # this will get from index 0 for 3 entries NOT third (3) index
print(friends[4])

friends[3] = "Leona"
print(friends[2:4])  # you can modify values by referencing array entry,
                   # handy in formulas like using existing values for calculating profit  (4 * 1.05)

number = [0,1,3,5,7]

number.append(6)  # you can use append method to add any number
number.insert(0,9) #inserts an element
number.remove(3)  #removes an element
number.clear  # clears all elements
print( 8 in number)  #boolean to test whether the number is in the list
print(len(number)) # returns the number of elements in the list

for item in number:
    print (item)

print(number)


                                           #LIST FUNCTIONS
lucky_numbers = [4, 5, 6, 8, 23, 45, 60]
friends = ["Bernard", "George", "Sam", "Jones", "Rita","Rita", "Rita","Sam"]
friends[6]="Leona"
#friends.extend(lucky_numbers)
print(friends)  # will simply add values of the other list inside the arguement into the host list
friends.append("{}{}".format("Allen"," Mutyanda"))  #this will always append an extra value to the end of the list
print(friends)
friends.insert(2, "Chipo")  #insert will insert the new array values at index position 2
print(friends)
friends.remove("Leona")  # removes a specific element from the list
print(friends)
# friends.clear()  # this will clear all the elements insides the list
friends.pop()  # will remove the last element on the list
print(friends)
print(friends.index("George"))  # searches the list for a specific value in an element
print(friends.count("Rita"))  # will count number of instances of the value Rita for the array element
friends.sort()  # sorts the list in ascending order, but looks like it can't be used co-jointly in one line to print it
print(friends)
lucky_numbers.reverse()  # reverses the element values inside the list
friends.reverse()
print(lucky_numbers)
friends2 = friends.copy()  # created another variable to contain a copy of the original variable friends
print(friends2)

                                             # T U P L E S

# A tuple stores multiple pieces of data, but different from a list
# tuples are immutable (cannot change/delete element
# tuples mainly used for data that will never changes like coordinates is a good example, age might not

coordinates = (4, 5)
print(coordinates[1])  # accessing elements by indexing
# friends[3] = "Leona"

#coordinates(4,5) = (9,5)
#coordinates[0] = 8
print(coordinates[0])  # errors out because tuples are immutable

                                           # F U N C T I O N S

# A function is a collection of code used to perform a set of task(s)
# whenever you have a group of code performing set of tasks, that's a perfect candidate for function creation, especially
# repetitive tasks

def say_hi():
    print("Hello user!!!")  # code has to be indented because if it's not python will not recognize it
say_hi() # this is how you call the function

def luda_party(name,place, chinena):
    #print("bring "+ name +" from " + place + " so we can chaya " + chinena) # not preferred for concatenation
    print("{}{}{}{}{}{}".format("bring ",name," from ",place," so we can chaya ",chinena)) # concatenate this way instead
# ("{}{}{}{}".format("zita"," rako"," ndiyani"," iwewe")) # concatenating string with no variables
luda_party("LudaSugar","Ponder","yellow gumbo")

# Now using parameters with the same function
def say_hi_with_parameters(name,age): #multipe parameter example
    #print("Hello " + name + " You are "+ age + " years old")
    print("{}{}{}{}{}".format("Hello ",name," , you are ", age," years old"))

say_hi_with_parameters("Bernard", "105")

                                        # RETURN STATEMENT FROM A FUNCTION
# Return word allows python to return information after function execution
def cube_num(num):
    pow(num, 3)
print(cube_num(10)) # you get the response NONE because there is no RETURN statement

def cube(num):
    return pow(num, 3)
#print(ceil(cube(3))) # now you get a result with the same function code after USING "RETURN" statement
result = cube(4) # creating a variable result to store the cube of 4, and then print it
print(floor(result))



                                      # IF STATEMENTS#

# Will need a boolean statement
is_male  = False

if is_male:
    print("You are a dude")
else:
    print("you are not a dude")

# a bit complex with OR operator
is_male  = False
is_tall  = True

if is_male or is_tall:
    print("You are either a dude or tall or both")
else:
    print("you are neither tall nor a dude")


# a bit complex with AND operator
is_male  = True
is_tall  = True

if is_male and is_tall:
    print("You are either a dude or tall or both")
else:
    print("you are neither tall nor a dude")


# More complex with ELIF/ELSE IF statement
is_male  = False
is_tall  = False

if is_male and is_tall:
    print("You are either a dude or tall or both")
elif is_male and not(is_tall):
    print("you are a short male")
elif not(is_male) and is_tall:
    print("you are tall but not a dude")
else:
    print("you are neither tall nor a dude")


                                               #IF STATEMENTS AND COMPARISON OPERATORS
# Creating a function first to pick up max value
def max_num(num1,num2,num3):
     return max(num1,num2, num3)
result = max_num(100,589,8)
print(result)


# Doing the same USING IF STATEMENTS
#!= (not equal) or == (equal) operators same as c#
def maxy_num(num1, num2, num3):
    if num1 >= num2 and num1 >= num3:
        return num1
    elif num2 >= num1 and num2 >= num3:
        return num2
    else:
        return num3

result = (maxy_num(100, 5, 8000))
print(result)



is_male = True
is_tall = True

if is_male and is_tall:
    print("you are a tall man")
elif is_male and not (is_tall):
    print(" you are a short male")
elif is_tall and not (is_male):
    print("you are a tall woman")
else:
    print("you are a short woman")

# print(max(4, 5,7))

                                                    #BUILDING A BETTER CALCULATOR WITH INCORPORATING IF STATEMENTS

num1 = float(input("Enter first number :"))
operator = input("Enter operator :")
num2 = float(input("Enter second :"))

if operator == "+":
   print(num1 + num2)
elif operator == "-":
   print(num1 - num2)
elif operator == "*":
   print(num1 * num2)
elif operator == "/":
   print(num1 / num2)
elif operator == "%":
   print(num1 % num2)
else:
    print("Invalid Operator "+ operator)


                                                   # DICTIONARIES
# A dictionary is a special structure in Python that allows you to store information in key value pair format
# Just like in a dictionary, the word would be the key and the value would  be the definition
# Dictionary is a Python Data Format while JSOn is actually a data format
# To Send the dictionary over the network, you have to convert it into a series of bytes (Serialization) 


monthconversions =    {
        1: "January",
        2: "February",
        3: "March",
        "Apr": "April",
        "May": "May",
        "Jun": "June",
        "Jul": "July",
        "Aug": "August",
        "Sep": "September",
        "Oct": "Octorber",
        "Nov": "November",
        "Dec": "December",
    }
## print(monthconversions[3]) # retrieving Value for the key
## print(monthconversions.get("Dec")) # another way of retrieving key, get will allow you to specify a default value not found inside dictionary
## print(monthconversions) ## printing the entire dictionary
## print(monthconversions["Nov"])
new_data = monthconversions.copy()  ## creating a new dictionary from an existing
print(new_data)
new_data.update({"Dec":"DCember"})  ##Updating a value for a key
## print(new_data["Dec"])
## print(monthconversions)

del new_data["Dec"]  ## deleting a key from a dictionary, using del will require square[] bracket
## print(new_data)
new_data.pop('Apr') ## Alternative way of removing a key from a dictionary
print(new_data)
##new_data.clear()  ## removing all keys in the dictionary
print(new_data)
monthconversions.keys()  ## shows all keys in the dictionary
new_data["InsertingNewKey"] = "NewKey"
print(new_data)

for key,value in new_data.items():  ##Looping a dictionary
        print(key)
        print(value)

countries = ['United States','Mexico','Canada','Brazil']   ## Using enumerate in looping to find position
for i, country in enumerate(countries):
        print(i)
        print(country)


                                  # WHILE LOOP
#While loop allows you to loop through a block and allow you to execute it a multiple times until a condition is met

i = 2
while i < 10:
    print(i)
    i += 2  # increment by 2 or i = i + 2, always use shorthand
print("Loop is done")

i = 4
while i <= 16:
        print(i)
        i += 4
print("Loop is complete")

                                 # Building a Guessing Game
secret_word = "girraffe"
guess = ""
guess_count = 0
guess_limit = 5
outof_guesses = False

while guess != secret_word and not(outof_guesses): # remember functions, loops, if statements always have to end with a colon(:) when defining
    if guess_count < guess_limit:
       guess = input("Enter guess word : ")
       guess_count += 1
    else:
       outof_guesses = True

if outof_guesses:
       print(" OOOh You Lose !!!")
else:
       print("Yeaaahy You win")



                                            # FOR LOOP
# For Loops are used to loop around collections like arrays or string of letters or numbers etc

for letter in "Girraffe Academy ":
    print(letter)

    t1 = "Brenda "
for w in t1:
    print(w)


# looping through an array
friends = ["Bernard", "Alex", "kate", "Luda"]
#len(friends)
for friend in friends:
    print(friend)

#print("{}{}{}".format("This ","is ","my", " car"))

i = 2
while i < 10:
    print(i)
    i += 2

else:
    print("loop is completed")

# indexing



for index in range(10):
    print(index) # the last number 10 in the range will not be included in the list

for index in range(3, 10):
    print(index) # the last number 10 in the range will not be included in the list

for i in range(1,10,2): ## range is from 1 through 10, 2 is the increment, this can also be equally replicated with a WHILE lOOP such as below
    print(i)

i = 1
while i <= 10:
        print(i)
        i += 2
        

# Looping through an array
friends = ["Bernard", "Alex", "kate", "Ludmila"]
for index in range(len(friends)):  # dynamically do this instead of hard cording array positions
                                   # the length of the array(len(friends) = 4 is actually the number of entries/elements in the array (4) not #chars
    print(friends[index])          # index for 0,1,2,3 and will not include 4 in the range

# Another use case
for index in range(5):
    if index == 0:
        print("First iteration")
    else:
        print("Not First Iteration")

print(3**4) ## 3 exponent 4 (3 to the power of 4)
print(floor(pow(3,4)))  # another way of 3 exponent 4

)

numbers = range(4,9,2)  # the numbers will not include the last digit 9, the third arguement is for the incremental
print(numbers[2])

for number in range(3,7,3):
    print(number)
    
    

                                #2 Dimensional Lists (2D List)
# below is a grid of 4 rows and 3 elements
number_grid = [
[1, 2, 3],
[3, 4, 5],
[6, 7, 8],
[9, 8, 7]
]
#print(number_grid[0][0])  # Accessing 1, put in row index followed by column index
#print(number_grid[2][2])  # Accessing 8, put in row index followed by column index
#print(number_grid[3][0])  # Accessing 0, put in row index followed by column index
# Using Nested FOR LOOPS to list out all elements in the 2D list

for row in number_grid:
for column in row:
print(column)


#BUILDING A BASIC TRANSLATOR IN PYTHON USING FUNCTIONS, IFs & FOR LOOPS
#translate all vowels to g for Giraffe language
def translate(phrase):
translation = ""   # always build a variable you can modify along the way carrying results for final return
for letter in phrase:
if letter in "AEIOUaeiou":
if letter.isupper():
translation = translation + "G"
elif letter.islower():
translation = translation + "g"
else:
translation = translation + letter
return translation

print(translate(input("Please Enter your word: ")))  # Combining print with function using an input function for the phrase


# EXCEPTIONS FOR ERROR HANDLING
try:
Answer = 10/2.5
Number = int(input("Enter a number only: "))
print(Number)
except ZeroDivisionError as err:
print(err)
except ValueError as err:
print(err)
except ArithmeticError as err:
print(err)

# READING, WRITING AND APPENDING FILES
# READ FILE

location = "C:/Users/bmutyanda/NEW_MISC2/MISC/CUMULUS/test4.txt"
work_file = open(location, "w")
#print(work_file.read())
work_file.close()



file_location = "C:/Users/bmutyanda/NEW_MISC2/MISC/CUMULUS/test.txt" # make sure slashes are forward slashes not back slashes
employee_file = open(file_location, "r")  # "r" for read
#print(employee_file.read())
print(employee_file.readable())   # evaluating whether the file is readable, it's a boolean
for employee in employee_file.readlines():  # readlines reads all the lines, and puts them in an array
         # Using for loop will break all the elements in the array into separate lines
print(employee)   # read will simply read the entire file

employee_file.close()

#open("employees.txt", "w") # "w" for write
#open("employees.txt", "a") # "a" for append and can only append without any modifying anything inside the file
#open("employees.txt", "r+") # "r+" for read and write


# WRITING TO FILES
# APPEND WILL ADD TO THE FILE
file_location = "C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\test.txt" # make sure slashes are forward slashes not back slashes
employee_file = open(file_location, "a")  # "a" for append
employee_file.write("{}{}".format("\nArchibald - Architect\n", "\nDentist\n"))  #ensure to include line break \n to move new entry to next line
# print(employee_file.readable())   # evaluating whether the file is readable, it's a boolean
employee_file.close()

# print to show the append worked
test_file = open(file_location, "r")
print(test_file.read())


# WRITE WILL OVERWRITE THE ENTIRE FILE
file_location = "C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\test.txt" # make sure slashes are forward slashes not back slashes
employee_file = open(file_location, "a")  # "w" for write
employee_file.write("\nAlex - Engineer\n")  #ensure to include line break \n to move new entry to next line
# print(employee_file.readable())   # evaluating whether the file is readable, it's a boolean
employee_file.close()

with open(file_location, "r") as F:
print(F.read())



# YOU CAN CREATE A NEW FILE WITH WRITE
file_location = "C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\test5.txt"
employee_file = open(file_location, "w")  # "a" for append and w for overwrite
employee_file.write("\nBernard - Engineer\n")  # ensure to include line break or escape key \n to move new entry to next line
# print(employee_file.readable())   # evaluating whether the file is readable, it's a boolean
employee_file.close()
with open(file_location, "r") as F:
print(F.read())



#import json
file_location = "C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\LLookup.csv"
with open(file_location,"r" ) as f:
print(f.name) # gives filename
print(f.mode) # mode as in reading
print(f.encoding)


#recommended way to open files - USE "with"

# Use Context variables because of the limited scope, once it's done, it automatically closes without having to explicitiy doing so

#import json

with open("C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\LLookup.csv","r") as f: # difference the variable is declared at the end, and looks like a CTE
print(f.name) # gives filename
print(f.mode) # mode as in reading
print(f.encoding)           
f.close() # close files is now optional and not needed when using "with" . Without "with without closing the file you run into a situation
# to avoid leaks, and running into exceeding multi descriptors causing errors                

# WRITING A FILE TO A CSV FILE
#Another example of limiting what you are writing for memory sake


with open("C:\\Users\\bmutyanda\\NEW_MISC2\\MISC\\CUMULUS\\LLookup.csv","r") as f: # difference the variable is declared at the end, and looks like a CTE
size_to_read = 3
f_contents = f.read(size_to_read)

while  len(f_contents) > 0:
print(f_contents, end='*')
f_contents = f.read(size_to_read)


# WORKING WITH JSONS (SERIALIZING & DESIRIALIZING)

# dump method converts data into jSon file
# dumps method converts data into a json string
# load method converts data from a json file
# loads method converts data from json string
# Desirializing from a JSON file:
import json

with open("states.json", "r") as f:  # difference the variable is declared at the end, and looks like a CTE
data = json.load(f)  # deserializing from a file
print(data)

for state in data["states"]:  # always remember the 'states' reference comes from the json object name
# del state['area_codes']
print(state["name"], state["abbreviation"])


with open("new_states.json", "w") as f:
json.dump(data, f, indent=2)       # Sirialized to a JSON new file

print('new_states.json')


# SERIALIZING INTO A  a new JSON FILE using the dump method and also removing one of the attributes

# Another Example

with open('test.json', 'r') as f:
data = json.load(f)
print(type(data))
for entry in data['dataset']:
column_names = entry['column_names'][0:10]
dataset_code = entry['dataset_code']
print(dataset_code,column_names)


# MODULE  & PIP
# A module is python file that we can import into our current python file because it functions and variables we can use(inheritance)
# Go to google and type in "list of python modules" (external modules)
# There are built in modules in python and also external modules are stored in the Lib folder
# we don't have to locate built in modules they just work because they are built into the IDE
# you can also install other modules written by the Python community out there
# You can use pip to install those python modules, and comes pre-installed in Python 3
# On Windows open up cmd prompt and run the following

from Student import Student

Student1 = Student('Bernard', 3.5, 'Computer', False)
Student2 = Student('Alex', 2.75,'Business', True)
print(Student1.major)
print(Student2.is_on_probation)


pip --version  #checks whether pip is installed or else find instructions to install it
pip install python-docx   # for installation
pip uninstall python-docx # for uninstallation

# This module will be installed in a special folder called: site packages colored brown
# Now use docx
import docx
docx.


# CLASSES & OBJECTS
# Classes allow you to create your own customized data types for an any object you wish to store information for
# create class below in a separate file and reference it later
"""
"""
class Student:  # student is the object, and also an instance of a class
    def __init__(self,name,major,gpa, is_on_probation):  # initializing the class
        self.name = name
        self.major = major
        self.gpa = gpa
        self.is_on_probation = is_on_probation
"""
"""
# now do the reference
from student import Student    # means from the student file import the student class
student1 = Student("Bernard", "Math", "3.42", "False")  # object student1
student2 = Student("Lisa", "English", "4.0", "False")  # object student2
print(student1.name)
print(student1.gpa)
print(student2.name)
print(student2.is_on_probation)

#*********************** will need to revisit the video example on multiple choice questions


                                 # CLASS OBJECT FUNCTIONS
# referencing the class function in student.py
from Student import Student

student1 = Student("Bernard",  3.1, "Math", True)  # make sure you pass in all the arguements inside the function
student2 = Student("Lisa",  2.0, "Science", False)

print(student1.on_honor_roll())  # referencing function on_honor_roll inside the Student Class inside Student.py
print(student2.on_honor_roll())  # mind how the parenthis are being used to call an object function unlike just a regular parameter

                                 # INHERITANCE
# Great stuff, will revisit from video and create example

                                 # PYTHON INTEPRETER
# will need to google how to install python 3 on my windows path variable in command prompt (cmd)
# this is a quick and dirty environment to test things out , but use the text editor for serious programming

                                # WORKING WITH DIRECTORIES ( PATH LIB, OS & FNMATCH MODULES)
# https://www.youtube.com/watch?v=_uQrJ0TkZlc&list=PLh4UHiGuXnsUw-5BTxI0oNiwwq7Fyt5qc&index=3&t=555s

from pathlib import Path
import os, fnmatch   # importing 2 modules at the same time

# Absolute Path - is the root drive of the computer disk like c:\ in windows
# Relative Path - is the current drive

path = Path("WorkingDirectory")
print(path.exists())  # checks to see if directory exists

path = Path("Emails")
print(path.mkdir())  # creates a new directory called Emails

path = Path("Emails")
print(path.rmdir())  # deletes the Emails directory

directory_location = "C:/Users/BZM/Desktop/PYTHON #/Emails" # creating a directory in a specific location
path = Path(directory_location)
print(path.mkdir())

os.getcwd()  ## get current directory
os.listdir()  ## list directory
os.makedirs("New_Folder")  ## making new directories

# os.walk() traverses the folders from top to down or bottom-up (top down is the default. It returns root directories
            # subdirectories, and filenames in the CURRENT DIRECTORY

# Looping the selected directory location for specific files or all using wildcard *.*
# Web reference: https://stackabuse.com/python-list-files-in-a-directory/

directory_location = "C:/Users/BZM/Desktop/CREDIT HISTORY/"
file_location = "C:/Users/BZM/Desktop/PYTHON #/DirectoryFiles.txt"
write_to_file = open(file_location, "w")
path = Path(directory_location)

list_of_files = os.listdir(path)
pattern = "*.*"
for entry in list_of_files:
    if fnmatch.fnmatch(entry, pattern):
        write_to_file.write(entry + os.linesep)  # linesep does the same thing as \n (escape)
         # print (entry) # you can choose to print the console or write to the file for easy manipulation

# Now using glob method from pathlib

                                    # AUTOMATION USING PYTHON
# Automate excel spreadsheets processing

                                    # HANDLING JSON FILES IN PYTHON
import json
import requests  # requests is a library that allows to read directly from quandl using an API instead of saving to a file prone to errors

# data = json.load(open("test.json"))   # use json.load for reading JSON file, and use json.loads for reading Strings
# Below is code to read JSON directly from a website through an API instead of the file as in the above
request = requests.get("https://www.quandl.com/api/v3/datasets/CHRIS/MGEX_IH1.json?api_key=NNsz83z_jx3pza7jRKii") # api KEY 
request_text = request.text
data = json.loads(request_text)  # This is deserializing into a JSON string format
print(data)   # reads the contents of the file
print(type(data))  # type will show us that this is a dictionary not a string

# ALTERNATIVE WAY OF MAKING THE SAME REQUEST ABOVE
import json
from urllib.request import  urlopen
with urlopen("https://www.quandl.com/api/v3/datasets/CHRIS/MGEX_IH1.json?api_key=NNsz83z_jx3pza7jRKii") as response:
     source = response.read()
data = json.loads(source)  # This is deserializing into a JSON string format
print(json.dumps(data, indent=2))  # reads the contents of the file
print(type(data))  # type will show us that this is a dictionary not a string



data_serialized = json.dumps(data)   #json_dumps serializes the the data in json format into a string
print(data_serialized)
print(type(data_serialized))

data_serialized = json.dump(data, open("api_file.json", "w"),  indent = 4)  # prefer to serialize into a file instead of json_dump
                                                               # since it's a lot of data to put into a variable
                                                               # "indent" key word helps formatting JSON into a readable format


                                    # REQUESTS LIBRARY

import requests
r = requests.get('https://s3-eu-west-2.amazonaws.com/newzimlive/wp-content/uploads/2019/09/02202219/Chitungwiza-Mayor-Lovemore-Maiko.jpg')
with open('Mayor.png', 'wb') as f:   # writing a file from a request from a website
    f.write(r.content)

# print(help(r))  # tells you how the content format for the request is handled together with other attributes
# print(r.status_code)  # 200 code is for success, 300 is redirects, 401 is  unauthorized response code, 500 is server errors
# print(r.headers)

# Using dictionary to pass parameters instead of explicitly keying them in the URL
payload = {'page': 2, 'count': 25}   # key and definition  (key pair)
r = requests.get('https://httpbin.org/get', params=payload) # instead of passing get parameter in the URLs , use the dictionaries instead
# print(r.text)
# print(r.url) # to test out the validity of the URL if we were to put the parameters manually: https://httpbin.org/get?page=2&count=25

# USING  POST Method
payload = {'username': 'Bendito', 'password': 'Trumpian'}
r = requests.post('https://httpbin.org/post', data=payload)

r_dictionary = r.json()
print(r_dictionary['form'])  # Accessing the particular key of the JSON format,
print(r.text)
print(r) # testing out the response code =  200 is good


                    # USING RANDOM NUMBER
import random
print(random.randint(45, 300))

# help("modules ")  LISTING ALL MODULES INSTALLED

            # WRITING A FILE TO A CSV FILE
import json
import csv

infile = open("person.json", "r")
outfile = open("person_csv.csv", "w")

writer = csv.writer(outfile, delimiter='%')

for row in json.loads(infile.read()):
    writer.writerow(row)



# Function to list files by type in a folder:
def Find_Files (directory_location, Write_file_location, file_type):
    path = Path(directory_location)
    list_of_files = os.listdir(path)
    pattern = file_type
    with  open(Write_file_location, "w") as write_to_file:
     for entry in list_of_files:
       if fnmatch.fnmatch(entry, file_type):
         write_to_file.write(entry + os.linesep)



# CREATING CLASSES FOR INHERITANCE
from pathlib import Path
import os, fnmatch

# Sample call:
class SearchFileDirectory:
    def __init__(self,directory_location,Write_file_location,file_type):
        self.path = Path(directory_location)
        self.list_of_files = os.listdir(self.path)
        pattern = file_type

        with open(Write_file_location, "w") as self.write_to_file:
            for entry in self.list_of_files:
                if fnmatch.fnmatch(entry, file_type):
                    self.write_to_file.write(entry + "       is in Folder Name:   " + directory_location + os.linesep)


class Student:  # student is the object, and also an instance of a class
    def __init__(self,name,major,gpa, is_on_probation):  # initializing the class
        self.name = name
        self.major = major
        self.gpa = gpa
        self.is_on_probation = is_on_probation


# Inheriting from a class(es) CREATED ABOVE 

from Class_DIR_Navigation import SearchFileDirectory, Student  # means from the Class_DIR_Navigation file import the SearchFileDirectory & Student class

# class SearchFileDirectory:
Search1 = SearchFileDirectory("C:/Projects & Architecture/Enterprise Architecture/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles.txt","*.json*")
Search2 = SearchFileDirectory("C:/Projects & Architecture/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles2.txt","*.pptx")
Search3 = SearchFileDirectory("C:/Projects & Architecture/Enterprise Architecture/Python/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles3.txt","*.*")

# class Student:
student1 = Student("Bernard", "Math", "3.42", "False")  # object student1
student2 = Student("Lisa", "English", "4.0", "False")  # object student2
student4 = Student('Benhild','Biology',4.0,'True')
print(student1.name)
print(student1.gpa)
print(student2.name)
print(student2.is_on_probation)
print(student4.is_on_probation)
print(str(student4.gpa) + ' with a major in ' + student4.major)


Find_Files("C:/Projects & Architecture/Enterprise Architecture/","C:/Projects & Architecture/Enterprise Architecture/PYTHON/DirectoryFiles.txt","*.txt")

# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
print("print this regardless")
print(f'__name__: {__name__}')
def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':   #this proves to someone reading your code that it's a script and can be run as opposed to a Library
    print_hi('PyCharm')



"""

            ## PANDAS


## Series is a 1 Dimensional Array
## Dataframe is a 2 Dimensional Array
