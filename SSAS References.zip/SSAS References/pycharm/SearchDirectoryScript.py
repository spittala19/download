from Class_DIR_Navigation import SearchFileDirectory


def main():
    Search2 = SearchFileDirectory("C:/Users/bmutyanda/NEW_MISC2/MISC/","C:/Users/bmutyanda/NEW_MISC2/MISC/CUMULUS/Write/DirectoryFilelist.txt","*.csv")

"""
with open("C:/Users/bmutyanda/NEW_MISC2/MISC/CUMULUS/Write/DirectoryFilelist.*.*", "r") as F:
    for row in F.readlines():
        print(row)
"""
if __name__ == '__main__':
    main()


