import pyodbc
from datetime import  datetime
import  os
import sqlite3 as sl

print (datetime.now())


class DownloadData():

    def __init__(self): 
        self.jdbcHostname = 'CRHRKSQLPRD01'
        self.jdbcDatabase = 'MRC'
        self.jdbcPort = 1433
        self.pyodbcUrl="DRIVER={ODBC Driver 17 for SQL Server};SERVER="+self.jdbcHostname+";DATABASE="+self.jdbcDatabase+";Trusted_Connection=yes"
        self.sqlLitePath = r'Desktop\RATESHEET\RATESHEET\my-test1.db'

        if os.path.exists(self.sqlLitePath):
            os.remove(self.sqlLitePath)
        else:
            print("Can not delete the file as it doesn't exists")


    def createtable(self):
        self.con = sl.connect(self.sqlLitePath)
        with self.con:
            self.con.execute("""
            CREATE TABLE RateSheetTestTable(
               [COMPANY] [varchar](239) NULL,
                [RSID] [varchar](50) NULL,
                [PROGRAM] [nvarchar](255) NULL,
                [DESCRIPTION] [nvarchar](255) NULL,
                [RATE] [decimal](4, 3) NULL,
                [7-Day] [decimal](11, 3) NULL,
                [15-Day] [decimal](11, 3) NULL,
                [30-Day] [decimal](14, 3) NULL,
                [45-Day] [decimal](11, 3) NULL,
                [60-Day] [decimal](11, 3) NULL,
                [75-Day] [decimal](11, 3) NULL,
                [90-Day] [decimal](11, 3) NULL,
                [PRICING DATE] [datetime2](3) NULL,
                [DAY ACTIVITY] [int] NULL,
                [FILE NAME] [varchar](8000) NULL,          
                [Delegation] [varchar](12) NOT NULL
                );
        """)
        
        self.con.close()


    def odbcdata(self,odbc_query):
        try:
            self.connection = pyodbc.connect(self.pyodbcUrl)
            self.conn =self.connection.cursor()
            self.result =   self.conn.execute(odbc_query)
        except Exception as e:
            print (str(e))
        #return self.result

    def insertsqllite(self):
        sql = 'INSERT INTO RateSheetTestTable (Company,RSID,PROGRAM,DESCRIPTION,RATE,[7-Day],[15-Day],[30-Day],[45-Day],[60-Day],[75-Day] ,[90-Day],[PRICING DATE],[DAY ACTIVITY] ,[FILE NAME],Delegation) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        con = sl.connect(self.sqlLitePath)
        with con:
            for row in self.result:
                #print(row[0],row[1],row[2])
                con.execute(sql,(str(row[0]),str(row[1]),str(row[2]),str(row[3]),str(row[4]),str(row[5]),str(row[6]),str(row[7]),str(row[8]),str(row[9]),str(row[10]),str(row[11]),str(row[12]),str(row[13]),str(row[14]),str(row[15])))
        con.close()
        print ('completed')



if __name__=='__main__':

    odbc_query= '''SELECT DISTINCT Company,RatesheetId,[PROGRAM],DESCRIPTION,RATE,[7-Day],[15-Day],[30-Day],[45-Day],[60-Day],[75-Day],[90-Day],[PRICING DATE],[Day ACTIVITY],[file name],Delegation FROM  dbo.RateSheetTestTable (nolock)
    WHERE RatesheetId =  10986  '''
    X = DownloadData()
    X.createtable()
    X.odbcdata(odbc_query)
    X.insertsqllite()
    print (datetime.now())

    del X