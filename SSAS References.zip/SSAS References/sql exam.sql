CREATE TABLE #temp ([MonthName] VARCHAR(20),[Month] INT, NetSales INT)


INSERT INTO #temp
--values('jan',1,85000)

VALUES('Jan',1,13400),
	  ('Feb',2,45000),
	  ('mar',3,45000),
	  ('Apr',4,50600),
	  ('May',5,47500)

SELECT 
		*
		, CASE WHEN  NetSales-lag(NetSales,3) OVER (ORDER BY MONTH ) >0 THEN 'Y' ELSE 'N' END AS IsBonusEligible 
FROM #Temp
	 


SELECT * FROM 	 
	 ;with cte 
	 as( 
  select *, ROW_NUMBER() over(order by NetSales desc) rn from #temp
  ) 
  select * from cte where  rn=2


  select * from #temp
  pres
  president




  SELECT MonthName, Month, NetSales, Lag(NetSales,1) OVER(ORDER BY Month) as lagNetSales FROM #TEMP

  SELECT MonthName, Netsales, SUM(NetSales)  OVER(PARTITION BY MonthName) AS SumTotalk  from #temp

  SELECT Rank() OVER(ORDER BY NetSales) as RNK,DENSE_RANK() OVER(ORDER BY Netsales) as Dns_rnk, Ntile(4) OVER(ORDER BY Netsales) as ntil, * from #temp

  
  SELECT DENSE_RANK() OVER(ORDER BY Netsales) as Dns_rnk, * from #temp


  SELECT 
	  *
	  , Rank() OVER(ORDER BY NetSales) 'RNK'
	  , ROW_NUMBER() OVER(Order BY NetSales) 'RowNum'
	  , DENSE_RANK() OVER(ORDER BY Netsales) 'DNS_RNK' 
	  , NTILE(4) OVER(ORDER BY NetSales) 'Ntil' 
  FROM #temp






  select * from #temp

  SELECT
    *
   ,SUM(NetSales) OVER(PARTITION BY Month) 'TotalNetSales'
   ,RANK() OVER(ORDER BY NetSales) 'RNK' 
   ,DENSE_RANK() OVER(ORDER BY NetSales) 'D_RNK'
   ,NTILE(4) OVER(ORDER BY NetSales) 'Ntile'

  FROM #temp
























SELECT
 *, LAG(NetSales,1) over(order by [Month]) PreviousSales
FROM #temp
















	  
	  select * from #temp
 /*** WINDOWS FUNCTIONS *****/ 
	SELECT MonthName,MONTH,NetSales,
       SUM(NetSales) OVER (ORDER BY [Month]) AS running_total
  FROM #temp






















SELECT *,LAG(NetSales,1) OVER (ORDER BY [Month]) as previous_month FROM #temp













	  select *,LAG (NetSales,2) over  (order by [Month]) from #temp as previous_netsales


	  select
	  *
	  from #temp
	  where NetSales > 45600



















SELECT * from #temp order by NetSales,monthname desc

WITH AS 
(select Netsales from #temp where  MONTHNAME='Jan') A

WITH AS 
(select Netsales,MONTHNAME from #temp where MONTHNAME='Feb') B

WITH AS 
(select Netsales,MONTHNAME from #temp where MONTHNAME='mar') C

WITH AS 
(select Netsales,MONTHNAME from #temp where MONTHNAME='Apr') D

WITH AS 
(select Netsales,MONTHNAME from #temp where MONTHNAME='may') E

Select













--drop table #temp

select 2/5.0


Don't use temp table
I don't know if create temp tables you can create indexes, I use table variable




	  select max(netsales) 
	   NetSales
	  from #temp
	  where netsales 
	  not in (select max(netsales) from #temp)
	
	


	
select LAG (NetSales,1) over  (order by [Month]) from #temp as previous_netsales


=> create & select into

=> delete & truncate

=> clustered index & non-clustered index

SELECT
 *
 ,CASE WHEN NetSales > PreviousSales THEN 'BONUS' ELSE 'NO BONUS' END AS 'Bonus Status'
FROM
(
	SELECT
	  *,
	  LAG(NetSales,1) OVER( ORDER BY [Month])  'PreviousSales'
	FROM #temp
) S


-- DROP TABLE #temp

	     
		 












-- two ways of creating a temp table

=> create & select into

=> delete & truncate

=> clustered index & non-clustered index

=> what is a Heap

=> Divide 5/2

SELECT 11/2

LAG(return_value ,offset [,default]) 
OVER (
    [PARTITION BY partition_expression, ... ]
    ORDER BY sort_expression [ASC | DESC], ...
)