--=============================================================================
--Find field
USE  originationsODS
SELECT *  from Information_Schema.columns  with (nolock)
WHERE column_name like '%BankAccountIdentifier%'
--AND (Table_Name LIKE '%')
-- OR Table_Name LIKE 'SMT%')
ORDER BY TABLE_NAME

 select
  top 10 BankAccountIdentifier,*
 
 from nsm.wire (nolock)   
--=============================================================================     

--Find where it's used
--VRSQLEDW01.DATA01.dbo.SRVUFO
USE report  
-
-USE dailyarchive

USE ORIGINATIONSods 
DECLARE @Searchtext varchar(1000)
SET @Searchtext = '%SellerLoanIdentifier%'
--declare @searchtext2 varchar(1000) = '%.%'
--BaseData.QuantumDataVolume


SELECT o.name, c.Text
FROM syscomments c
JOIN sysobjects o ON c.id=o.id
WHERE c.Id IN (SELECT Id FROM syscomments WHERE text like @SearchText )
AND c.ColId = 1
--and c.Id IN (SELECT Id FROM syscomments WHERE text like @searchtext2 )
ORDER BY c.Id, c.ColId

--select a string in all databases
Query1.
EXEC sp_MSForEachDB 'USE [?]; IF DB_NAME() NOT IN (''msdb'',''master'',''tempdb'')
BEGIN
       
       SELECT 
              db = DB_NAME()
              ,TableSchema = s.name
              ,TableName = t.Name
              ,ColumnName = c.Name
              ,ConstraintName = dc.Name
              ,dc.definition
              ,AlterConstraintCommand =''ALTER TABLE [''+db_name() + ''].['' +s.name +''].['' +t.Name + ''] DROP CONSTRAINT IF EXISTS '' +dc.Name +''; ''
                     + ''ALTER TABLE ['' +db_name() + ''].['' +s.name +''].['' +t.Name + ''] ADD CONSTRAINT '' +dc.Name +'' DEFAULT (CONVERT(DATETIME, SYSDATETIMEOFFSET()  AT TIME ZONE ''''Central Standard Time'''')) FOR ['' +c.Name + '']''

       FROM sys.tables t
              JOIN sys.schemas s ON t.schema_id = s.schema_id
              JOIN sys.default_constraints dc ON t.object_id = dc.parent_object_id
              JOIN sys.columns c ON dc.parent_object_id = c.object_id AND c.column_id = dc.parent_column_id
       WHERE 
              t.Name <> ''MSsnapshotdeliveryprogress''
              --and t.Name not like ''Parameter%''
              and DB_NAME() not like ''ReportServer%''
              --and c.Name <> ''Populated_Date''
              and dc.definition LIKE ''%getdate%''
       ORDER BY t.Name

END
'


Query2.

EXEC sp_MSForEachDB 'USE [?]; IF DB_NAME() NOT IN (''msdb'',''master'',''tempdb'')
BEGIN
SELECT DB_NAME() as DBName, OBJECT_NAME(id) AS name
, text FROM syscomments WHERE text LIKE ''%GETDATE()%''
and OBJECT_NAME(id) not like ''%MSins%''
and OBJECT_NAME(id) not like ''%MSupd%''
and OBJECT_NAME(id) not like ''%MSdel%''
END
'
 
-- CHECKING ODS REPLICATION LATENCY

SELECT
MAX(ODSLastUpdateDate) AS ODSLastUpdateDate
,MAX(LoanSource.LoanSourceLastUpdate) as LoanLastModified
FROM
[MISMO].Loan Loan with (nolock)
join [NSM].LoanSource LoanSource with (nolock) on Loan.LoanNumber = LoanSource.LoanNumber and LoanSource.LoanSourceType = 'Encompass'
where 1=1
and LoanSource.TestLoanIndicator = 0 --CX.LOAN.INDICATOR + Deleted Flag
and LoanSource.LoanFolderName not in ('(Trash)','iLead','Inquiries','Old Prospects','Temp','Purged Other')



--verifying whether one is reading the Azure Sql read only copy
SELECT DATABASEPROPERTYEX(DB_NAME(), 'Updateability');

--Checking Row for all tables


sp_msforeachtable 'EXEC sp_spaceused [?]'

\\Crbiissqlprd01\SSIS\FundingTapes\Jefferies\Archive

CLOUD MI:
ORIGRPTPROD (Data Source=origrptprod.f664dfbfa6b3.database.windows.net;Initial Catalog=Reports)
    

CRSSRSTST01\VRSQLBI2016_MD 

sp_help 'NSM.BorrowerVerificationtype'

-- CHECKING STATISTICS UPDATE
SELECT sp.stats_id, 
       name, 
       filter_definition, 
       last_updated, 
       rows, 
       rows_sampled, 
       steps, 
       unfiltered_rows, 
       modification_counter
FROM sys.stats AS stat
     CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
WHERE stat.object_id = OBJECT_ID('tbl_LoanServicing_Hack');


-- Checking Driver Status
execute master.dbo.xp_enum_oledb_providers

--how to Mask a column
CREATE TABLE DynamicDataMaskExample(
	[ID]		INT IDENTITY(1,1),
	[Name]		VARCHAR(20),
	[Phone]	BIGINT,
	[Email]	VARCHAR(30)
)
 
INSERT INTO DynamicDataMaskExample ([Name],[Phone],[Email])
VALUES ('John',9876543210,'john.doe@yahoo.com'),('Bob',5879612546,'bob.marley@google.com')

/***** EXECUTION ******/
CREATE USER MaskUser WITHOUT LOGIN; 
GRANT SELECT ON DynamicDataMaskExample TO MaskUser;

ALTER TABLE DynamicDataMaskExample  
ALTER COLUMN [Name] VARCHAR(20) MASKED WITH (FUNCTION = 'default()');

EXECUTE AS USER = 'MaskUser'
SELECT * FROM DynamicDataMaskExample
REVERT
GO


--Foreign Key Example
create table Loans 
        (loan varchar(15), 
		 amount int,
		 CONSTRAINT PK_Loans PRIMARY KEY NONCLUSTERED (loan)
		 )

CREATE table deleted 
( loanNumber varchar(15),
  UPB int, 
  Names varchar(40),
   CONSTRAINT PK_loanNumber PRIMARY KEY NONCLUSTERED (loanNumber)
      , CONSTRAINT FK_Loans FOREIGN KEY (loanNumber)
	    REFERENCES Loans (loan)
  )

  INSERT INTO Loans
  values('2099039', 2890489),
  ('3099039', 2890489),
  ('4099039', 2890489),
  ('5099039', 2890489)

  INSERT INTO deleted
  VALUES ('2099039', 2890489,'Bernard'),
		 ('3099039', 2890489,'Mutyanda'),
         ('4099039', 2890489,'Nagaraju'),
         ('5099039', 2890489,'Sandeep')

DELETE Loans where loan =  '4099039'


SELECT 
 * 
FROM loans (NOLOCk)


SELECT 
 * 
FROM deleted





ALTER TABLE DynamicDataMaskExample
ALTER COLUMN [Email] VARCHAR(30) MASKED WITH (FUNCTION = 'email()');

ALTER TABLE DynamicDataMaskExample  
ALTER COLUMN [Phone] VARCHAR(20) MASKED WITH (FUNCTION = 'partial(2,"XXXXX",3)');

-- Checking MASKED columns on a database
	USE OriginationsODS
	GO

	SELECT 
	 masking_function
	,* 
	FROM sys.masked_columns


	select name, masking_function,* from sys.masked_columns(nolock)
-- Stats_ID: It is the unique ID of the statistics object
-- Name: It is the statistics name
-- Last_updated: It is the date and time of the last statistics update
-- Rows: It shows the total number of rows at the time of the last statistics update
-- Rows_sampled: It gives the total number of sample rows for the statistics
-- Unfiltered_rows: In the screenshot, you can see both rows_sampled and unfiltered_rows value the 
   same because we did not use any filter in the statistics
-- Modification_counter: It is a vital column to look. We get the total number of modifications since the last statistics update

--VIEW DEFINITION SCRIPT----

SELECT
    definition,
    uses_ansi_nulls,
    uses_quoted_identifier,
    is_schema_bound
FROM
    sys.sql_modules
WHERE
    object_id
    = object_id(
            'vw_JSON_parser'
        );


--=============================================================================
 -- count # of tables in a database
SELECT COUNT(*)
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'

----TABLE COUNT
USE OriginationsODS

SELECT 
   *
FROM INFORMATION_SCHEMA.TABLES (nolock)
WHERE TABLE_TYPE = 'BASE TABLE'
AND TABLE_SCHEMA  IN ('MISMO','DBO','NSM')

-- database list & servername
SELECT 
  Name,
  @@SERVERNAME,*
FROM   master.sys.databases (nolock)
WHERE  Cast(CASE WHEN name IN ('master', 'model', 'msdb', 'tempdb') THEN 1 ELSE is_distributor END As bit) = 0


--Below are the SQL scripts I use to check if the loans sent from Upstream PacU servers to ODS. 

/* Run this is ON WAREHOUSE server PUFDW DB */
DECLARE @LoanList TABLE 
       (
              PACU_LoanNum VARCHAR(20)
       ) 
	   
INSERT INTO @LoanList
(
       PACU_LoanNum
) 
VALUES /*change the loan number here */
('7001339501'),
('7001353676')


--PACU TO ODS_ORIG RECON
SELECT TOP 100 ODSLastUpdateDate [TIME],* FROM MISMO.LOAN(NOLOCK)
WHERE LoanNumber LIKE '3%' OR loannumber LIKE '5%'
ORDER BY ODSLastUpdateDate DESC

Query 2 :

SELECT max(ODSLastUpdateDate) FROM OriginationsODS.MISMO.LOAN A 
JOIN ORIGINATIONSODS.NSM.LOANSOURCE B
ON A.LOANNUMBER=B.LOANNUMBER WHERE LoanSourceType IN ('OpenCloseWS','DataTrac')


-- Checking for Loan existence for Open Close
SELECT * FROM OCrepl.dbo.LoanNames WHERE name = '7000940611'

-- DETERMINING PACU REPLICATION ACTIVITIES 
;WITH FOLDERS AS  /* New Loans Created ?? */
(
       SELECT TOP 1 
       DateCreated  
       FROM OCREPL.dbo.FOLDERS (NOLOCK)  
       ORDER BY DateCreated DESC 
),
ACTIIVITES AS    /* New Activities Happened ?? */
(
       SELECT TOP 1 
       DateCreated   
       FROM OCREPL.dbo.Activities (NOLOCK)  
       ORDER BY ActivityID DESC 
),
LOGINS AS  /* Anyone LoggedIn today ?? */
(

       SELECT  TOP 1 
       LoginTimeStamp AS DateCreated  
       FROM   
       OCRepl.dbo.EntityLogins (NOLOCK) 
       ORDER BY LoginTimeStamp DESC 

) 
SELECT 
/* Check if any activities happened today */
CASE 
       WHEN CAST (MAX(DateCreated) AS DATE) = CAST (GETDATE() AS DATE) 
       THEN 'There Are Some Activities Today' 
       ELSE 'No Activities Today'
END AS Result 
FROM 
(
       SELECT DateCreated FROM FOLDERS
       UNION 
       SELECT DateCreated FROM ACTIIVITES
       UNION 
       SELECT DateCreated FROM LOGINS
)a 


------------------
---MOXI QUERY AND DATE UPDATE

--database server:orig_ods\OriginationsODS

UPDATE NSM.Wire
SET WireRecipientBankCity = 'St.Charles',
    WireRecipientBankState = 'MO'
       ABARoutingAndTransitIdentifier = '081000993'
WHERE LoanNumber = '668796972' 

UPDATE MISMO.Loan
       SET ODSLastUpdateDate = GETDATE()
WHERE LoanNumber= '668796972'


--Data Lake JSON storage tables for DTC 7 Loan Logic
ORGN_DATA_LAKE.dbo.ENC_LOAN_DATA  - DTC
ORGN_DATA_LAKE.dbo.CORR_LOAN_DATA - Loan Logics


SELECT TOP 10  
json_value(loan_data_obj, '$."Loan"."364"') as LoanNumber,
json_value(loan_data_obj, '$."Loan"."CX.STATUS"') as LoanStatus,
json_value(loan_data_obj, '$."Loan"."CX.SUBSTATUS"') as LoanSubStatus,
json_value(loan_data_obj, '$."Loan"."CX.LEAD.LOAN.NUMBER"') as ServicingLoanNumber
from dbo.ENC_LOAN_DATA_LTST(nolock)

-- 

mrcoopersynapseworkspacepoc-ondemand.sql.azuresynapse.net


mrcoopersynapseworkspacepoc.sql.azuresynapse.net

sqlpooltest
9Zu!nB@123



-- type your sql script here, we now have intellisense
USE testpool
GO

CREATE VIEW vw_JSON_parser

AS

SELECT  --count(*)
--json_value(FullLine, '$."Loan"."14"') as state
--count(json_value(FullLine, '$."Loan"."364"')) as loancount
  json_value(FullLine, '$."Loan"."364"') as loanNumber
 ,json_value(FullLine, '$."Loan"."14"') as state
 ,json_value(FullLine, '$."Loan"."CX.STATUS"') as LoanStatus
 ,json_value(FullLine, '$."Loan"."CX.SUBSTATUS"') as LoanSubStatus
 ,json_value(FullLine, '$."Loan"."CX.LEAD.LOAN.NUMBER"') as ServicingLoanNumber
--,json_value(FullLine, '$."Loan"."CX.LEAD.LOAN.NUMBER"') as ServicingLoanNumber
FROM OPENROWSET(
BULK --'https://lakejohnson.blob.core.windows.net/harishblob/*',
      'https://lakejohnson.blob.core.windows.net/harishblob/041*.json',
--'https://synapseprimarystorage.dfs.core.windows.net/synapsetempdata/json/snaptest/*',

FORMAT='CSV',FIELDTERMINATOR ='0x0b', FIELDQUOTE = '0x0b', ROWTERMINATOR = '0x0b') 
WITH (FullLine VARCHAR(MAX)) s 

--group by json_value(FullLine, '$."Loan"."14"')
--order by json_value(FullLine, '$."Loan"."14"')

--total 1590
--USER-ACCOUNT SEARCH
SELECT 
 * 
FROM MASTER.sys.server_principals (NOLOCK)
WHERE NAME like '%Bat%' 


SELECT 'Do these loans had wirefunddate on last ETL run?' AS 'Query1'
SELECT PACU_LoanNum, WireFundDate FROM [DM_MCI].[Wire] WHERE PACU_LoanNum IN ( SELECT PACU_LoanNum FROM @LoanList)

SELECT 'Were these loans sent to ODS in last batch?'  AS 'Query2'
SELECT  * FROM [DM_MCI].LoanQueuedLog WHERE PACU_LoanNum IN ( SELECT PACU_LoanNum FROM @LoanList)

SELECT 'What is the fundsorderdate in OpenClose?'  AS 'Query3'
SELECT DISTINCT name, FundsOrderedDate  from PWDCRPT02.OCRepl.dbo.rpt_doc_Funding  f with(nolock)
JOIN PWDCRPT02.OCRepl.dbo.loannames ln on f.folderid = ln.folderid 
where ln.name in (  SELECT PACU_LoanNum FROM @LoanList)

-- checking for replication if new loans are flowing

/*** CHECKING LOANS WITHIN THE WAREHOUSE TABLE READY FOR FUNDING******/
-- USE PWDCSQSD01

USE PUFDW
go

SELECT
*
from DM_MCI.Wire (nolock)
where WireFundDate > getdate() -1 and PACU_LoanNum  like '7%'



-- USE PWDCRPT02
USE OCrepl
go

SELECT TOP (1000) [FolderID]
      ,[FundingSource]
      ,[FundingType]
      ,[AnticipatedFundsOrderedDate]
      ,[FundsOrderedDate]
      ,[FundsOrderedBy]
      ,[FundedDate]
      ,[FundedBy]
      ,[DisbursementType]
      ,[DisbursementEffectiveDate]
      ,[CheckOrWireNum]
      ,[AdvanceAmountRequested]
      ,[DisbursementAmount]
      ,[WarehouseBank]
      ,[WarehouseAccountCode]
      ,[WarehouseLoanNum]
      ,[ObligationNum]
      ,[CommitmentNum]
      ,[BankABANum]
      ,[DebitAccountNum]
      ,[PayeeName]
      ,[WireApprovedDate]
      ,[WireApprovedBy]
      ,[WireVoidedDate]
      ,[WireVoidedBy]
      ,[FedReferenceNum]
      ,[DestinationBankName]
      ,[DestinationBankABANum]
      ,[DestinationBankCity]
      ,[BeneficiaryName]
      ,[BeneficiaryAccountNum]
      ,[WireComments]
      ,[Haircut]
      ,[WireImpounds]
      ,[InterestForValue]
      ,[PPIChecked]
      ,[ImpoundsChecked]
      ,[FinalAPR]
      ,[FurtherCreditTo]
      ,[FurtherCreditToAcctNumber]
      ,[FurtherCreditToBankABA]
      ,[PrepaidInterest]
      ,[PTFCleared]
      ,[PTFClearedBy]
      ,[WireBankAcctName]
      ,[BeneficiaryAddress]
      ,[BeneficiaryCityStateZip]
      ,[InvestorCode]
      ,[DestinationBankAddress]
      ,[DestinationBankAcctName]
      ,[FundedTime]
      ,[WireApprovedTime]
      ,[WireVoidedTime]
      ,[PTFClearedTime]
  FROM [OCrepl].[dbo].[rpt_doc_Funding] (nolock)
  where FundsOrderedDate > getdate()-1

--CROSS APPLY

The CROSS APPLY operator returns only those rows from the left table expression (in its final output) 
if it matches with the right table expression. In other words, the right table expression returns rows for 
the left table expression match only.
The OUTER APPLY operator returns all the rows from the left table expression irrespective of its match with
 the right table expression. For those rows for which there are no corresponding matches in the right table 
 expression, it contains NULL values in columns of the right table expression.
So you might conclude, the CROSS APPLY is equivalent to an INNER JOIN (or to be more precise its like a CROSS JOIN 
with a correlated sub-query) with an implicit join condition of 1=1 whereas the OUTER APPLY is equivalent to a LEFT OUTER JOIN.
 
So in summary the APPLY operator is required when you have to use a table-valued function in the query, but it can also be
used with inline SELECT statements.

  CREATE TABLE [Department]
  ( 
   [DepartmentID] [int] NOT NULL PRIMARY KEY, 
   [Name] VARCHAR(250) NOT NULL, 
  ) ON [PRIMARY] 

INSERT [Department] ([DepartmentID], [Name])  
VALUES (1, N'Engineering') 
INSERT [Department] ([DepartmentID], [Name])  
VALUES (2, N'Administration') 
INSERT [Department] ([DepartmentID], [Name])  
VALUES (3, N'Sales') 
INSERT [Department] ([DepartmentID], [Name])  
VALUES (4, N'Marketing') 
INSERT [Department] ([DepartmentID], [Name])  
VALUES (5, N'Finance') 
GO 

CREATE TABLE [Employee]( 
   [EmployeeID] [int] NOT NULL PRIMARY KEY, 
   [FirstName] VARCHAR(250) NOT NULL, 
   [LastName] VARCHAR(250) NOT NULL, 
   [DepartmentID] [int] NOT NULL REFERENCES [Department](DepartmentID), 
) ON [PRIMARY] 
GO
 
INSERT [Employee] ([EmployeeID], [FirstName], [LastName], [DepartmentID]) 
VALUES (1, N'Orlando', N'Gee', 1 ) 
INSERT [Employee] ([EmployeeID], [FirstName], [LastName], [DepartmentID]) 
VALUES (2, N'Keith', N'Harris', 2 ) 
INSERT [Employee] ([EmployeeID], [FirstName], [LastName], [DepartmentID]) 
VALUES (3, N'Donna', N'Carreras', 3 ) 
INSERT [Employee] ([EmployeeID], [FirstName], [LastName], [DepartmentID]) 
VALUES (4, N'Janet', N'Gates', 3 ) 

--Script #2 - CROSS APPLY and INNER JOIN

SELECT * FROM Department D 
CROSS APPLY 
   ( 
   SELECT * FROM Employee E 
   WHERE E.DepartmentID = D.DepartmentID  /******TAKE NOTE OF WHERE instead of ON when using APPLY ****/
   ) A 
GO
 
SELECT * FROM Department D 
INNER JOIN Employee E ON D.DepartmentID = E.DepartmentID 
GO 


SELECT * FROM Department D 
OUTER APPLY 
   ( 
   SELECT * FROM Employee E 
   WHERE E.DepartmentID = D.DepartmentID 
   ) A 
GO
 
SELECT * FROM Department D 
LEFT OUTER JOIN Employee E ON D.DepartmentID = E.DepartmentID 
GO 

--Script #4 - APPLY with table-valued function

IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[fn_GetAllEmployeeOfADepartment]') AND type IN (N'IF')) 
BEGIN 
   DROP FUNCTION dbo.fn_GetAllEmployeeOfADepartment 
END 
GO
 
CREATE FUNCTION dbo.fn_GetAllEmployeeOfADepartment(@DeptID AS INT)  
RETURNS TABLE 
AS 
RETURN 
   ( 
   SELECT * FROM Employee E 
   WHERE E.DepartmentID = @DeptID 
   ) 
GO
 
SELECT * FROM Department D 
CROSS APPLY dbo.fn_GetAllEmployeeOfADepartment(D.DepartmentID) /***by not specifying Dept ID, you match on all of them ***/
GO
 
SELECT * FROM Department D 
OUTER APPLY dbo.fn_GetAllEmployeeOfADepartment(D.DepartmentID) 
GO 

--Script #5 - APPLY with Dynamic Management Function (DMF)

USE master 
GO
 
SELECT DB_NAME(r.database_id) AS [Database], st.[text] AS [Query]  
FROM sys.dm_exec_requests r 
CROSS APPLY sys.dm_exec_sql_text(r.plan_handle) st 
WHERE r.session_Id > 50           -- Consider spids for users only, no system spids. 
AND r.session_Id NOT IN (@@SPID)  -- Don't include request from current spid. 



-- USE ORIG_ODS with, replace sample loans with real loans from above

USE OriginationsODS 
GO

SELECT
*
FROM NSM.Wire (NOLOCK)
WHERE LoanNumber IN ('7001480214'
,'7001512305'
,'7001520498'
,'7001529705'
,'7001531412'
,'7001540702'
,'7001545958'
,'7001547681'
,'7001550461'
,'7001551824'
,'7001551949'
,'7001559363'
,'7001564280')


*************windows******************
to get machine IP address
Pinging crorgsqlprd01.chec.local [10.64.200.40] with 32 bytes of data:
Reply from 10.64.200.40: bytes=32 time=16ms TTL=126
Reply from 10.64.200.40: bytes=32 time=22ms TTL=126
Reply from 10.64.200.40: bytes=32 time=25ms TTL=126
Reply from 10.64.200.40: bytes=32 time=26ms TTL=126

Ping statistics for 10.64.200.40: (IP Address)
    Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),
Approximate round trip times in milli-seconds:
    Minimum = 16ms, Maximum = 26ms, Average = 22ms

msinfo32
----------------------------
-------------- triaging LOAN LOGIC ISSUES-----------------------------
Here are the queries :

--------------------------------------------------------TRIMS-----------------------------------------------------

------ODS/OUTBOUND-----

DECLARE @LOAN VARCHAR(16) = '668676968'

SELECT LoanPurposeType,RefinanceCashOutDeterminationType,ODSLastUpdateDate,NoteDate FROM OriginationsODS.MISMO.Loan (nolock) WHERE LoanNumber=@LOAN

SELECT * FROM OriginationsODS.NSM.LoanStatus (nolock) WHERE LoanNumber=@LOAN

SELECT W.WireAmount as WireAmount, W.WireDate as WireDate, W.BankAccountIdentifier as BankAccNumber, W.ABARoutingandTransitIdentifier as ABANumber, 
W.AccountName as PayeeName, W.InstitutionName as BankName, W.WireRecipientBankCity as BankCity, W.WireRecipientBankState as BankState
FROM OriginationsODS.NSM.wire W (nolock) WHERE LoanNumber=@LOAN

SELECT * FROM Outbound..LoanLogics_WireRequest (nolock) WHERE LoanNumber=@LOAN

SELECT * FROM Outbound..LoanLogics_WireReject (nolock) WHERE LoanNumber=@LOAN

SELECT * FROM Outbound.dbo.Originations_RejectData (NOLOCK) WHERE LoanNumber=@LOAN

select Loannumber,Etl_created_date,Etl_updated_date,LoanPurposeDetail,Program,ProductDescription,ProductId,WireDate,WireRecipientAddress,
CorrAddress1,   CorrCity,              CorrState,       CorrZIP,BorrowerFirstName,BorrowerLastName,NoteDate,WireRecipientCity,WireRecipientState,WireRecipientZIP
,NoteDate FROM outbound.[dbo].tbl_TrimsExtract where loannumber =@LOAN
order by ETL_Load_Id desc 

----------TEMPORAL TABLES
CREATE TABLE dbo.LoanAppTrack1
  (
   Loanid INT IDENTITY PRIMARY KEY,
   LoanNumber varchar(10),
   [MONTH]  INT,
   [STATUS] VARCHAR(5),
   SysStartTime datetime2 Generated ALWAYS AS ROW START NOT NULL,
   SysEndTime  datetime2 Generated ALWAYS AS ROW END NOT NULL,
   PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)
  )

  WITH
  (
    SYSTEM_VERSIONING = ON (HISTORY_TABLE  =  dbo.LoanAppTrackHistroy1)
  )

  INSERT INTO LoanAppTrack1 (LoanNumber,MONTH,STATUS)
  VALUES('10000430',04, 'S'),
        ('89099999',09, 'Y')
 

  update dbo.LoanAppTrack1 set STATUS = 'F' where LoanNumber = '10000430' AND LoanID = 2
  update dbo.LoanAppTrack1 set STATUS = 'G' where LoanNumber = '89099999'

  delete from dbo.LoanAppTrack1 where LoanNumber = '89099999'
  ------ ALL UPDATES BELOW ARE EXACTLY THE SAME, BUT STILL CREATE A COPY OF UNCHANGED DATA------

  update dbo.LoanAppTrack1 set STATUS = 'L' where LoanNumber = '10000430'
  update dbo.LoanAppTrack1 set STATUS = 'M' where LoanNumber = '89099999'

  update dbo.LoanAppTrack1 set STATUS = 'L' where LoanNumber = '10000430'
  update dbo.LoanAppTrack1 set STATUS = 'M' where LoanNumber = '89099999'

  update dbo.LoanAppTrack1 set STATUS = 'L' where LoanNumber = '10000430'
  update dbo.LoanAppTrack1 set STATUS = 'M' where LoanNumber = '89099999'

  SELECT * FROM dbo.LoanAppTrack1 (NOLOCK)
  SELECT * FROM dbo.LoanAppTrackHistroy1 (NOLOCK)

DROP TABLE  REPORTS.dbo.LoanAppTrackHistroy1 

--- TO perform DML operations independently, you need to alter system-versioning TABLE
ALTER TABLE REPORTS.dbo.LoanAppTrack1 SET (SYSTEM_VERSIONING = OFF)
ALTER TABLE REPORTS.dbo.LoanAppTrack1 SET (SYSTEM_VERSIONING = ON)
		



------TRIMS DATABASE-----

SELECT Loannumber,Etl_created_date,Etl_updated_date,LoanPurposeDetail,Program,ProductDescription,ProductId,WireDate,WireRecipientAddress,
CorrAddress1,   CorrCity,              CorrState,       CorrZIP,BorrowerFirstName,BorrowerLastName,NoteDate,WireRecipientCity,WireRecipientState,WireRecipientZIP
,NoteDate
FROM TRIMS..tbl_PacificUnion (NOLOCK) WHERE Loannumber  IN ('668676968')

 
 
 --------------------------------------------------------LSAMS-----------------------------------------------------
DECLARE @LOAN VARCHAR(16) = '668696511'
select * from  outbound..NLSDSR                                             WHERE LOAN_NBR_10                  =@LOAN AND ETL_Load_Id>0
select * from  outbound..NLSALT2                            where loan_number                       =@LOAN and ETL_LOAD_ID>0
select * from  outbound..NLSALT3                            where loan_number                       =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSALT5                            where loan_number                       =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSBAL                                              WHERE loan_number                    =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSCHG                                            WHERE loan_NBR                                            =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSCHGV                          where loan_number                       =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSDSR                                             WHERE LOAN_NBR_10                  =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSESCE                            where loan_number                       =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSESCM                          where loan                                                         =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSLGLD                           where loan_number                       =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSMAST2                       WHERE loan_number                    =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSMLD                                            WHERE loan_number                    =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NLSNECHG                       where NGLOAN                                               =@LOAN            and ETL_LOAD_ID>0
select * from  outbound..NSMFLDT                         WHERE loan_number                      =@LOAN            and ETL_LOAD_ID>0

 
 Links to Reports:
http://iservprd:10088/prod/PublishedReports/public/index/opendate?category=Servicing&report=DIH%20REPORT&date=2017-01-10#2017-01-10
http://iservprd:10088/prod/PublishedReports/public/index/opendate?category=Servicing&report=NewLnEdit&date=2019-06-28#2019-06-28

 
ADHOC SERVER QUERY:
SELECT * FROM CHEC..SRVDSR WHERE _LOAN_NUM_N='668680903'


-----------------------------------------------------=====================================-----------------------------------------------------



CMD to search for AD groups
--gpresult /V > AD_GROUPS.txt 

--database size
use "OriginationsODS"
exec sp_spaceused

--SET TRANSACTON LEVEL READ UNCOMITTED
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
--

--@[User::FilePath_Local] + @[User::FileName_Prefix] + "LoanServicing" +  @[User::FileName_Suffix] + ".csv" loan servicing connection string
 --SQL SERVER VERSION
 SELECT @@VERSION

sp_helptext usp_CompassExtract

select * from INFORMATION_SCHEMA.ROUTINES where ROUTINE_DEFINITION like '%SRVDSR%' AND ROUTINE_NAME  LIKE '%Data%'  =-- from Hollie

--when last was the stored proc altered
select LAST_ALTERED,* from INFORMATION_SCHEMA.ROUTINES where SPECIFIC_NAME ='usp_Data_ARM'

--my DBA kit
sp_who2 active   /***which session is live, and possibly who is blocking who***/

DECLARE @Table TABLE(
        SPID INT,
        Status VARCHAR(MAX),
        LOGIN VARCHAR(MAX),
        HostName VARCHAR(MAX),
        BlkBy VARCHAR(MAX),
        DBName VARCHAR(MAX),
        Command VARCHAR(MAX),
        CPUTime INT,
        DiskIO INT,
        LastBatch VARCHAR(MAX),
        ProgramName VARCHAR(MAX),
        SPID_1 INT,
        REQUESTID INT
)

INSERT INTO @Table 
EXEC sp_who2

SELECT  *
FROM    @Table
where login = 'sa'
order by CPUTime desc

OR

SELECT  spid,
        sp.[status],
        loginame [Login],
        hostname, 
        blocked BlkBy,
        sd.name DBName, 
        cmd Command,
        cpu CPUTime,
        physical_io DiskIO,
        last_batch LastBatch,
        [program_name] ProgramName
FROM master.dbo.sysprocesses sp  (nolock)
JOIN master.dbo.sysdatabases sd  (nolock) ON sp.dbid = sd.dbid
ORDER BY spid 


KILL 223

dbcc inputbuffer(121) /**what proc is buffering**/


----DATABASE SIZE BY TABLE USAGE -----

create table #TableSize (
    Name varchar(255),
    [rows] int,
    reserved varchar(255),
    data varchar(255),
    index_size varchar(255),
    unused varchar(255))
create table #ConvertedSizes (
    Name varchar(255),
    [rows] int,
    reservedKb int,
    dataKb int,
    reservedIndexSize int,
    reservedUnused int)

EXEC sp_MSforeachtable @command1="insert into #TableSize
EXEC sp_spaceused '?'"
insert into #ConvertedSizes (Name, [rows], reservedKb, dataKb, reservedIndexSize, reservedUnused)
select name, [rows], 
SUBSTRING(reserved, 0, LEN(reserved)-2), 
SUBSTRING(data, 0, LEN(data)-2), 
SUBSTRING(index_size, 0, LEN(index_size)-2), 
SUBSTRING(unused, 0, LEN(unused)-2)
from #TableSize

select * from #ConvertedSizes
order by reservedKb desc

drop table #TableSize
drop table #ConvertedSizes 

--ALTER TABLE tbl_LoanLookupReference add primary key ([LoanNumber],[ProcessName])

--ALTER TABLE tbl_LoanLookupReference
--ALTER COLUMN ProcessName VARCHAR(70) NOT NULL

kill 290 /***destroy specific session***/
use msdb 

xp_logininfo 'chec\reports-admin',AD members

SELECT * FROM fn_virtualservernodes()  /* cluster machine names*/

--to be able to find out if your extract has been FTP'ed from VRSQLSSIS01 you can always browse to the WS FTP log on VRSQLSSIS01 and confirm that. The name of the file is ws_ftp.log and is located under 

\\VRSQLSSIS01\Users\sqladm\AppData\Roaming\Ipswitch\WS_FTP\Logs

  
  VRSQLNLB01N01 & VRSQLNLB01N02  SSRS instances

  CRREPSQLPRD01 & CRREPSQLPRD02 for CRRPTPSQLPRD01 instance


\\vrsqlwc01n03\Users\sqladm\AppData\Roaming\Ipswitch\WS_FTP

Hama3940#C:\Users\sqladm\AppData\Roaming\Ipswitch\WS_FTP\Logs

--Report Manager log files
\\vrsqlssrs01\logfiles\
\\vrsqlssrs\Program Files\Microsoft SQL Server\MSRS10_50.MSSQLSERVER\Reporting Services

\\vrsqlwcdev16\E$
--LPMA Production folder remote shared folder
\\VRISI01\shared$\RSHARE\LPMA Production Files\


\\VRDMZSFTP02\BI_Reporting_Test_Site$\  /***BI SFTP test site****/
/*Mike's bridge: Migration to New Cluster - Replication Re-architecture   866.873.7151 & 2698551*/
Conference Bridge
866.873.7151

Paticipant: 2698551
Host: 9246435

\\vrsqlwc01n03\
\\vrsqlwc01n02\
\\vrsqlwc01n01\


/****** FIND RUNNING QUERIES, AND KILL THEM IF POSSIBLE ********/
SELECT 
	sqltext.TEXT,
	req.session_id,
	req.status,
	req.command,
	req.cpu_time,
	req.total_elapsed_time
FROM sys.dm_exec_requests req
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sqltext
--While running above query if you find any query which is running for long time it can be killed using following command.
--KILL�[session_id]
use ReportServer 

SELECT
 TOP 100 SD.SCHEDULEID,sd.ScheduleID , C.*
FROM Subscriptions   S(NOLOCK)
JOIN Catalog  C (NOLOCK) ON S.Report_OID = C.ItemID 
JOIN ReportSchedule R (NOLOCK) ON  R.ReportID  = s.Report_OID 
JOIN Schedule SD (NOLOCK) ON SD.ScheduleID = r.ScheduleID 
WHERE c.Name LIKE 'rptWeeklyDashboardByChannel%'


---Shows Params/Types/Time per subscription
USE ReportServer


SELECT

[InstanceName]

,[ItemPath]

,[UserName]

,[ExecutionId]

,[RequestType]

,[Format]

,[Parameters]

,[ItemAction]

,[TimeStart]

,[TimeEnd]

,datediff(second,[TimeStart], [TimeEnd]) as duration_seconds

,[TimeDataRetrieval]

,[TimeProcessing]

,[TimeRendering]

,[Source]

,[Status]

,[ByteCount]

,[RowCount]

,[AdditionalInfo]
,MONTH([TimeStart] ) ExecutionMonth
, CAST([TimeStart] AS DATE) TimeStart

FROM [ReportServer].[dbo].[ExecutionLog3]

where 1=1

AND requestType = 'subscription'

and [TimeStart] > '2021-03-01'

--and [TimeStart] < '2021-05-04'

--and [TimeStart] > '2021-05-10 18:00:00'

--and [TimeStart] < '2021-05-11 18:00:00'

and [ItemPath] like '%Employee Report%'

--and RequestType='Subscription'

--and Status='rsSuccess'

--and UserName='CHEC\SVC_VRSQLWNLB01_ADM'

--and Parameters like '%EmployeeID=100120776%'

--and Parameters like '%EmployeeID=100119020%'

--and Parameters like '%EmployeeID=100117478%'

--and Parameters like '%EmployeeID=100120343%'

--and Parameters like '%EmployeeID=100115270%'

--AND username LIKE '%dulay%'�

--and Parameters like '%EmployeeID=100115697%'

--and Parameters like '%EmployeeID=100103839%'

--order by [TimeStart] DESC



---	# pending per subscription

SELECT [SubscriptionID], COUNT([SubscriptionID]) AS PendingJobsOfThisSubscripion 
FROM [ReportServer].[dbo].[Notifications] group by [SubscriptionID]


--Which subscriptions are pending

USE ReportServer
GO

DECLARE @count INT

SELECT
Cat.[Name]
,Cat.Path
,Sub.[LastRunTime]
   --  Rep.[ScheduleId]
   --  Own.UserName
   --ISNULL(REPLACE(Sub.[Description],'send e-mail to ',''),' ') AS Recipients

,Sub.[LastStatus]


FROM
       dbo.[Subscriptions] Sub with (NOLOCK)
INNER JOIN
       dbo.[Catalog] Cat with (NOLOCK) on Sub.[Report_OID] = Cat.[ItemID]
INNER JOIN
       dbo.[ReportSchedule] Rep with (NOLOCK) ON (cat.[ItemID] = Rep.[ReportID] and Sub.[SubscriptionID] =Rep.[SubscriptionID])
INNER JOIN
       dbo.[Users] Own with (NOLOCK) on Sub.[OwnerID] = Own.[UserID]
WHERE 1=1
--AND Cat.[Path] LIKE '%compensation%'
--AND cat.name IN (

--)
AND Sub.LastStatus NOT IN ('disabled')
AND Sub.LastStatus NOT LIKE 'Error: Invalid object name%'
AND Sub.LastStatus NOT LIKE 'Error: Log on failed%'
--AND cat.name = 'Manager Report'

ORDER BY Sub.[LastRunTime] desc





DECLARE @count INT
 
SELECT
       Cat.[Name],
       Rep.[ScheduleId],
       Own.UserName,
       ISNULL(REPLACE(Sub.[Description],'send e-mail to ',''),' ') AS Recipients,
       Sub.[LastStatus],
       Cat.[Path],
       Sub.[LastRunTime]

 
FROM
       dbo.[Subscriptions] Sub with (NOLOCK)
INNER JOIN
       dbo.[Catalog] Cat with (NOLOCK) on Sub.[Report_OID] = Cat.[ItemID]
INNER JOIN
       dbo.[ReportSchedule] Rep with (NOLOCK) ON (cat.[ItemID] = Rep.[ReportID] and Sub.[SubscriptionID] =Rep.[SubscriptionID])
INNER JOIN
       dbo.[Users] Own with (NOLOCK) on Sub.[OwnerID] = Own.[UserID]
WHERE
Cat.[Path] LIKE '%/Reports/Compensation%'



select
*
from Subscriptions 
where LastStatus  like '%Pending%'
order by LastRunTime desc


exec msdb.dbo. 

MSF BOA monthly file from Jennifer SFTP sitename
OK I will go ahead and send both files... it is the BOA_LSBO connection for this group in the /incoming/lsbo folder
--sp_who2 active

--dbcc inputbuffer(290)
--kill 290


--non-scheduled tasks

-- USE REPORTS
-- GO
 
-- SELECT
-- *
-- FROM ReportLayout..tbl_Jobs_Users (NOLOCK)
 
-- SELECT
-- *
-- FROM ReportLayout..tbl_Jobs (NOLOCK)
-- WHERE DESCRIPTION LIKE '%INCENTIVE%'
 

--INSERT ReportLayout..tbl_Jobs_Users (JOBID,dOMAINACCOUNT)
--VALUES (44,'tguillen')

-- IP ADDRESS QUERY
select local_net_address,* FROM sys.dm_exec_connections

--Requires SQL 2008 +

SELECT

ConnectionProperty('net_transport') AS 'net_transport',

ConnectionProperty('protocol_type') AS 'protocol_type',

ConnectionProperty('auth_scheme') AS 'auth_scheme',

ConnectionProperty('local_net_address') AS 'local_net_address',

ConnectionProperty('local_tcp_port') AS 'local_tcp_port',

ConnectionProperty('client_net_address') AS 'client_net_address',

ConnectionProperty('physical_net_transport') AS 'physical_net_transport'


---checking replication for Max
--I ran the following query..
SELECT * FROM PWDCSQL07.AppDev.dbo.v_Data_Refresh_Datetimes



disbursement loan selector:

--TRIMS PROD
SELECT 
		  BR.BankReportID
		, LR.ReportID
		, BR.BankReportTypeID
		, BR.BankReportCreateDateTime
		, COUNT(LR.LoanNbr)AS LOAN_COUNT
FROM TRIMS.dbo.tbl_BankReport BR (nolock)
JOIN TRIMS.dbo.tbl_LoanReporting LR (NOLOCK) ON BR.BankReportID = LR.InternalReportID
WHERE BR.BankReportCreateDateTime > GETDATE()-1
--WHERE LR.LoanNbr = '134482998'
--WHERE LR.ReportID = '2E3F8042-F0BD-4410-ACFF-7CEC5CD7FD1C'
GROUP BY BR.BankReportID, LR.ReportID, BR.BankReportTypeID, BR.BankReportCreateDateTime
ORDER BY BR.BankReportCreateDateTime DESC


SELECT
 TOP 10 *
FROM TBL_LoanReporting LR (NOLOCK)

  --find dups in staging tables  
  SELECT
    BK.LoanNumber ,LN.PortfolioId ,INV.PortfolioDescription ,INV.SurveillanceCompany,  COUNT(*)    
  FROM [LPMA_NEW].[dbo].[tbl_Data_Loan]           BK
  JOIN DBO.vw_LoanList                                LN  ON BK.LoanNumber  = LN.LoanNumber 
  JOIN DBO.tbl_Investors                              INV ON LN.PortfolioId = INV.PortfolioID 
  WHERE inv.PortfolioID = 'ftb'--ArchivedDate = '02/01/2013'
  GROUP BY BK.LoanNumber ,LN.PortfolioId ,INV.PortfolioDescription ,INV.SurveillanceCompany
  HAVING COUNT(*) > 1
  ORDER BY 3
  
  DSR pwd: uYSK7rtMKkA3cVMtOIq0
  	  
	SELECT
	  command ,*
	FROM  msdb.dbo.sysjobsteps  (nolock)
	WHERE command like '%Dailysnapshot%'
  
  Patrick file location: \\vrisi01\shared$\RSHARE\Capital Markets\Proventure\Development\MonFileDatabaseImport
  
  --msdb..sp_start_job @job_name = '09DE1DAA-04E7-44D5-A680-0EC05B6F21E7' /******DelinquencySummary_byPortfolio***/
  
  --rerun the sql server AGENT job '09DE1DAA-04E7-44D5-A680-0EC05B6F21E7' on VRSQLREPORTS\REPORTS_PROD TO FIX pending DSR JOB WHEN DSR SNAPSHOT FAILS
  
  
  --VRSQLSSRS01\Application Pools\ for IIS start jobs recycling
  
  
  ----step 7 & 7b with Karim
  
  Bernard Mutyand...	Mr Karim, this is Bernard, got a question about an update to an LSAMS table to clear the end day to 0. Our SSIS ETL package wasn't able to update that flag showing a no authority to do so on that object CDATA.LSPRCSTS00
Bernard Mutyan...	here is the update statement:
Bernard Mutyan...	SET 
LSSTS = 0,
LSUPDDTE = '08/13/2013 09:50:52'
WHERE LSPRCNM = 'ENDDAY'
Bernard Mutyan...	the date is not really showing what it was at the time, I just generated the current date
Bernard Mutyan...	I will be in a meeting for the next hour, so I will try to call you when I am back. Thanks
Bernard Mutyan...	SELECT
 TOP 5 LSPRCNM,LSSTS,LSUPDDTE,*
FROM AS400.IASP01.CDATA.LSPRCSTS00
WHERE LSPRCNM = 'ENDDAY'
Bernard Mutyan...	UPDATE CDATA.LSPRCSTS00
SET 
LSSTS = 0,
LSUPDDTE = '08/13/2013 09:50:52'
WHERE LSPRCNM = 'ENDDAY'
Karim Genaidy/...	we are setting this to '0'
Bernard Mutyan...	so you set this to Zero all the time ? does this happen before end day starts ?
Karim Genaidy/...	at beginning
Bernard Mutyan...	because I was just wondering whether it's even necessary for us to be writing if  will end up getting the Status 1 indicating endday is done, because that's what need need a status of 1 on field LSSTS
Karim Genaidy/...	we also set it to '1'
Karim Genaidy/...	after we are done w/step 7
Bernard Mutyan...	7B that is right?
Bernard Mutyan...	looks like this is a redudant step on our end
Karim Genaidy/...	after 7 ... 7b won't be complete yet
Bernard Mutyan...	gotcha
Bernard Mutyan...	I am pretty sure that we are not the only one looking for this flag, so anyone else might not rely on us writing to this because LSAMS does it already, is that a fair statement
Karim Genaidy/...	i'm not sure who the subscriber's are 
Bernard Mutyan...	if you guys update to 0 at the beginning, and 1 at the end, I am willing to disable our portion
Bernard Mutyan...	what the difference between 7 & 7B
Bernard Mutyan...	this will help me make a decision
Karim Genaidy/...	7b ... is referred to as when our critical batch jobs (like investor cutoff) are completed.
Karim Genaidy/...	7 is when our basic "in-line" endday processing is done
Karim Genaidy/...	banking/loan balances updated
Bernard Mutyan...	so flag is only set to 1 right after 7 or 7 B, which one comes first, sorry for too many questions, this is my opportunity to understand
Karim Genaidy/...	step 7
Bernard Mutyan...	I can tell you that for this job, I am mainly interested in copying SRVDSR records
Bernard Mutyan...	so that would be which one as for the 7 & 7B
Karim Genaidy/...	step 7
Bernard Mutyan...	so that means I am good because the flag is set to 1 for SRVDSR since it's in STEP 7 



/****sql task to pull investors from tbl_investornumbers back into robot control table for robot migration

SELECT 
	 PortfolioID 
	,PortfolioSubgroup
    ,REPLACE(STUFF((SELECT ',  ' + InvestorNumber   FROM LPMA_NEW.dbo.tbl_InvestorNumbers  WHERE (ISNULL(PortfolioID,'ALL') = INV.PortfolioID) /*(PortfolioSubgroup = INV.PortfolioSubgroup)*/ FOR XML PATH ('')),1,2,''),' ','') AS Investors /*** Concatenates all the INVESTORS, and tie them to one grouped loan***/
--INTO #Inserted
FROM LPMA_NEW.dbo.tbl_InvestorNumbers (NOLOCK) INV 
WHERE PortfolioID LIKE 'FTB%'
AND PortfolioSubgroup  is null	
GROUP BY PortfolioID 
	    ,PortfolioSubgroup
		
SELECT 
	 PortfolioID 
	,PortfolioSubgroup
    ,REPLACE(STUFF((SELECT ',  ' + InvestorNumber   FROM LPMA_NEW.dbo.tbl_InvestorNumbers  WHERE (PortfolioID = INV.PortfolioID) AND (PortfolioSubgroup = INV.PortfolioSubgroup) FOR XML PATH ('')),1,2,''),' ','') AS Investors /*** Concatenates all the INVESTORS, and tie them to one grouped loan***/
INTO #Inserted
FROM LPMA_NEW.dbo.tbl_InvestorNumbers (NOLOCK) INV 
WHERE PortfolioID LIKE 'FTB%'
AND PortfolioSubgroup  IN ( 'FTB_ABS',
							'ftb_als2',
							'FTB_BB',
							'FTB_BH',
							'FTB_BK',
							'FTB_BOA1',
							'ftb_boa2',
							'FTB_BONY_GS',
							'FTB_BONY_HE4',
							'FTB_BONY_SEC',
							'FTB_BONYM1',
							'FTB_BONYM2',
							'FTB_BSAMSWF',
							'FTB_BSASetupWF',
							'FTB_BSMSWF',
							'FTB_BV1',
							'FTB_BV2',
							'FTB_BVF',
							'FTB_CFS',
							'FTB_CH',
							'FTB_CITIM_VLB',
							'FTB_CITIM1',
							'FTB_CitiM2',
							'FTB_CSFB_WFMS',
							'FTB_DBC',
							'FTB_DEL',
							'FTB_DOVE',
							'FTB_DYNC',
							'FTB_EB',
							'FTB_EMCWF',
							'FTB_ENB',
							'FTB_ET',
							'FTB_FHLBWF',
							'FTB_FHLMC_FTBMS',
							'FTB_FREMAC',
							'FTB_FTB',
							'FTB_GNMA',
							'FTB_GS',
							'FTB_HH',
							'FTB_HOCMONT',
							'FTB_HSB',
							'FTB_ISB1',
							'FTB_ISB2',
							'FTB_KY',
							'FTB_LEHAL',
							'FTB_LSBNA',
							'FTB_LSGTS1',
							'FTB_LSGTS2',
							'FTB_MLR',
							'FTB_MMDBMS',
							'FTB_NHD',
							'FTB_OW',
							'FTB_RBSC',
							'FTB_RFCORP',
							'FTB_RM',
							'FTB_SBSLA',
							'FTB_SMI',
							'FTB_STCB',
							'FTB_SWSFSB',
							'FTB_TDHCA',
							'FTB_ThronWF',
							'FTB_TOB',
							'FTB_UBSWF',
							'FTB_UCSB',
							'FTB_USBA',
							'FTB_VB',
							'FTB_WCS',
							'FTB_WFB1',
							'FTB_WFB2',
							'FTB_WFB3',
							'FTB_WMMORT',
							'FTB_WMMSEC'
									)

GROUP BY  PortfolioID
		 ,PortfolioSubgroup 		




UPDATE  INV SET
    Investor = INS.Investors 
 --,INS.Investors 
 --,INV.Portfolia 
 --,INS.PortfolioID 
 --,INV.PortfolioSubgroup 
 --,INS.PortfolioSubgroup  
FROM #Inserted                             INS
JOIN LPMA_NEW.dbo.tbl_LPMA_ROBOT_CONTROLS  INV  ON  INV.Portfolia         = INS.PortfolioID 
												    AND INV.PortfolioSubgroup = INS.PortfolioSubgroup 	

******/

--IF STATEMENT IN SSIS: ( @[User::PortfolioSubgroup] == "ALL"? @[User::Portfolio] +" "+" LPMA ROBOT Export" : @[User::PortfolioSubgroup] +" "+"LPMA ROBOT Export") 



CREATE PROCEDURE TestEmailOnFail
AS
BEGIN
    BEGIN TRY
        /*
            Perform some action that might fail
        */
        SELECT 0/0; --THIS WILL FAIL
    END TRY
    BEGIN CATCH
        DECLARE @subject nvarchar(max) = 'Job Failure Notification';
        DECLARE @body nvarchar(max) = 'TestEmailOnFail Job Failed' 
            + CHAR(10) + CHAR(13) + 'Error Number:  ' + CAST(ERROR_NUMBER() AS nvarchar(max))
            + CHAR(10) + CHAR(13) + 'Error Message: ' + ERROR_MESSAGE();
        DECLARE @to nvarchar(max) = 'somebody@email.com';
        DECLARE @profile_name sysname = 'SQLMailProfileName';
        EXEC msdb.dbo.sp_send_dbmail @profile_name = @profile_name,
            @recipients = @to, @subject = @subject, @body = @body;
    END CATCH
END




/**************************************************************BELOW ARE QUERIES TO USED TO QUERY SQL AGENT INFORMATION******************************************************************************/

/***
Agent Job Properties window in SSMS.

SELECT 
    [sJOB].[job_id] AS [JobID]
    , [sJOB].[name] AS [JobName]
    , [sDBP].[name] AS [JobOwner]
    , [sCAT].[name] AS [JobCategory]
    , [sJOB].[description] AS [JobDescription]
    , CASE [sJOB].[enabled]
        WHEN 1 THEN 'Yes'
        WHEN 0 THEN 'No'
      END AS [IsEnabled]
    , [sJOB].[date_created] AS [JobCreatedOn]
    , [sJOB].[date_modified] AS [JobLastModifiedOn]
    , [sSVR].[name] AS [OriginatingServerName]
    , [sJSTP].[step_id] AS [JobStartStepNo]
    , [sJSTP].[step_name] AS [JobStartStepName]
    , CASE
        WHEN [sSCH].[schedule_uid] IS NULL THEN 'No'
        ELSE 'Yes'
      END AS [IsScheduled]
    , [sSCH].[schedule_uid] AS [JobScheduleID]
    , [sSCH].[name] AS [JobScheduleName]
    , CASE [sJOB].[delete_level]
        WHEN 0 THEN 'Never'
        WHEN 1 THEN 'On Success'
        WHEN 2 THEN 'On Failure'
        WHEN 3 THEN 'On Completion'
      END AS [JobDeletionCriterion]
FROM
    [msdb].[dbo].[sysjobs] AS [sJOB]
    LEFT JOIN [msdb].[sys].[servers] AS [sSVR]
        ON [sJOB].[originating_server_id] = [sSVR].[server_id]
    LEFT JOIN [msdb].[dbo].[syscategories] AS [sCAT]
        ON [sJOB].[category_id] = [sCAT].[category_id]
    LEFT JOIN [msdb].[dbo].[sysjobsteps] AS [sJSTP]
        ON [sJOB].[job_id] = [sJSTP].[job_id]
        AND [sJOB].[start_step_id] = [sJSTP].[step_id]
    LEFT JOIN [msdb].[sys].[database_principals] AS [sDBP]
        ON [sJOB].[owner_sid] = [sDBP].[sid]
    LEFT JOIN [msdb].[dbo].[sysjobschedules] AS [sJOBSCH]
        ON [sJOB].[job_id] = [sJOBSCH].[job_id]
    LEFT JOIN [msdb].[dbo].[sysschedules] AS [sSCH]
        ON [sJOBSCH].[schedule_id] = [sSCH].[schedule_id]
ORDER BY [JobName]
The following is a brief description of each of the fields returned from the above query:

[JobID]: A unique identifier for the SQL Server Agent job (GUID).
[JobName]: Name of the SQL Server Agent job.
[JobOwner]: Owner of the job.
[JobCategory]: Category to which the job belongs like Replication Snapshot, Database Maintenance, Log Shipping, etc.
[JobDescription]: Description of the job.
[IsEnabled]: Indicator representing whether the job is enabled or disabled.
[JobCreatedOn]: Date and time when the job was created.
[JobLastModifiedOn]: Date and time when the job was last modified.
[OriginatingServerName]: Server from which the job executed.
[JobStartStepNo]: Step number from which the job is set to start. SQL Server allows us to have multiple steps within a job and the job can be set to start from whichever step the user wants it to start from.
[JobStartStepName]: Name of the step from which the job is set to start.
[IsScheduled]: Indicator representing whether the job is scheduled or not. The jobs can be either scheduled to run on specified day(s) at a specified time or can be invoked through code like T-SQL, etc.
[JobScheduleID]: Unique identifier of the schedule associated with the job (GUID).
[JobScheduleName]: Name of the schedule associated with the job. SQL Server allows us to associate multiple schedules with one job, in which case, the above query would return one row for each schedule associated with each job.
[JobDeletionCriterion]: The criterion for deleting the job. SQL Server Agent has a feature which allows us to delete/drop the job based on a certain criterion so that there is no need to manually delete/cleanup the jobs.
SQL Server Agent Job Execution Information

SQL Server Agent stores the history of job execution in system tables in msdb database.

The following query gives us the details of last/latest execution of the SQL Server Agent Job and also the next time when the job is going to run (if it is scheduled). This information can also be found in the Job History/Job Activity Monitor windows in SSMS.

SELECT 
    [sJOB].[job_id] AS [JobID]
    , [sJOB].[name] AS [JobName]
    , CASE 
        WHEN [sJOBH].[run_date] IS NULL OR [sJOBH].[run_time] IS NULL THEN NULL
        ELSE CAST(
                CAST([sJOBH].[run_date] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBH].[run_time] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [LastRunDateTime]
    , CASE [sJOBH].[run_status]
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 4 THEN 'Running' -- In Progress
      END AS [LastRunStatus]
    , STUFF(
            STUFF(RIGHT('000000' + CAST([sJOBH].[run_duration] AS VARCHAR(6)),  6)
                , 3, 0, ':')
            , 6, 0, ':') 
        AS [LastRunDuration (HH:MM:SS)]
    , [sJOBH].[message] AS [LastRunStatusMessage]
    , CASE [sJOBSCH].[NextRunDate]
        WHEN 0 THEN NULL
        ELSE CAST(
                CAST([sJOBSCH].[NextRunDate] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBSCH].[NextRunTime] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [NextRunDateTime]
FROM 
    [msdb].[dbo].[sysjobs] AS [sJOB]
    LEFT JOIN (
                SELECT
                    [job_id]
                    , MIN([next_run_date]) AS [NextRunDate]
                    , MIN([next_run_time]) AS [NextRunTime]
                FROM [msdb].[dbo].[sysjobschedules]
                GROUP BY [job_id]
            ) AS [sJOBSCH]
        ON [sJOB].[job_id] = [sJOBSCH].[job_id]
    LEFT JOIN (
                SELECT 
                    [job_id]
                    , [run_date]
                    , [run_time]
                    , [run_status]
                    , [run_duration]
                    , [message]
                    , ROW_NUMBER() OVER (
                                            PARTITION BY [job_id] 
                                            ORDER BY [run_date] DESC, [run_time] DESC
                      ) AS RowNumber
                FROM [msdb].[dbo].[sysjobhistory]
                WHERE [step_id] = 0
            ) AS [sJOBH]
        ON [sJOB].[job_id] = [sJOBH].[job_id]
        AND [sJOBH].[RowNumber] = 1
ORDER BY [JobName]
The following is a brief description of each of the fields returned from the above query:

[JobID]: A unique identifier for the SQL Server Agent job (GUID) for which the execution history is being reported.
[JobName]: Name of the SQL Server Agent job.
[LastRunDateTime]: Date and time when the job was run last time (corresponds to the most recent run).
[LastRunStatus]: Status or outcome of the last job run.
[LastRunDuration (HH:MM:SS)]: Duration of the last run represented in Hours:Minutes:Seconds format.
[LastRunStatusMessage]: More descriptive message about the job status/outcome.
[NextRunDateTime]: Date and time when the job will run next time. This information is available only for the jobs which are scheduled (a schedule is associated with a job).
SQL Server Agent Job Steps Setup and Configuration Information

In SQL Server Agent, a job is the parent level entity, which contains one or more steps. A step is the child/low level entity, which contains the actual commands/instructions for performing a specific task. Whereas a job defines the sequence of execution of steps, schedule for running steps, etc.

The following query gives us the Job Step level Setup and Configuration information, which can also be found in the Job Step Properties window in SSMS.

SELECT
    [sJOB].[job_id] AS [JobID]
    , [sJOB].[name] AS [JobName]
    , [sJSTP].[step_uid] AS [StepID]
    , [sJSTP].[step_id] AS [StepNo]
    , [sJSTP].[step_name] AS [StepName]
    , CASE [sJSTP].[subsystem]
        WHEN 'ActiveScripting' THEN 'ActiveX Script'
        WHEN 'CmdExec' THEN 'Operating system (CmdExec)'
        WHEN 'PowerShell' THEN 'PowerShell'
        WHEN 'Distribution' THEN 'Replication Distributor'
        WHEN 'Merge' THEN 'Replication Merge'
        WHEN 'QueueReader' THEN 'Replication Queue Reader'
        WHEN 'Snapshot' THEN 'Replication Snapshot'
        WHEN 'LogReader' THEN 'Replication Transaction-Log Reader'
        WHEN 'ANALYSISCOMMAND' THEN 'SQL Server Analysis Services Command'
        WHEN 'ANALYSISQUERY' THEN 'SQL Server Analysis Services Query'
        WHEN 'SSIS' THEN 'SQL Server Integration Services Package'
        WHEN 'TSQL' THEN 'Transact-SQL script (T-SQL)'
        ELSE sJSTP.subsystem
      END AS [StepType]
    , [sPROX].[name] AS [RunAs]
    , [sJSTP].[database_name] AS [Database]
    , [sJSTP].[command] AS [ExecutableCommand]
    , CASE [sJSTP].[on_success_action]
        WHEN 1 THEN 'Quit the job reporting success'
        WHEN 2 THEN 'Quit the job reporting failure'
        WHEN 3 THEN 'Go to the next step'
        WHEN 4 THEN 'Go to Step: ' 
                    + QUOTENAME(CAST([sJSTP].[on_success_step_id] AS VARCHAR(3))) 
                    + ' ' 
                    + [sOSSTP].[step_name]
      END AS [OnSuccessAction]
    , [sJSTP].[retry_attempts] AS [RetryAttempts]
    , [sJSTP].[retry_interval] AS [RetryInterval (Minutes)]
    , CASE [sJSTP].[on_fail_action]
        WHEN 1 THEN 'Quit the job reporting success'
        WHEN 2 THEN 'Quit the job reporting failure'
        WHEN 3 THEN 'Go to the next step'
        WHEN 4 THEN 'Go to Step: ' 
                    + QUOTENAME(CAST([sJSTP].[on_fail_step_id] AS VARCHAR(3))) 
                    + ' ' 
                    + [sOFSTP].[step_name]
      END AS [OnFailureAction]
FROM
    [msdb].[dbo].[sysjobsteps] AS [sJSTP]
    INNER JOIN [msdb].[dbo].[sysjobs] AS [sJOB]
        ON [sJSTP].[job_id] = [sJOB].[job_id]
    LEFT JOIN [msdb].[dbo].[sysjobsteps] AS [sOSSTP]
        ON [sJSTP].[job_id] = [sOSSTP].[job_id]
        AND [sJSTP].[on_success_step_id] = [sOSSTP].[step_id]
    LEFT JOIN [msdb].[dbo].[sysjobsteps] AS [sOFSTP]
        ON [sJSTP].[job_id] = [sOFSTP].[job_id]
        AND [sJSTP].[on_fail_step_id] = [sOFSTP].[step_id]
    LEFT JOIN [msdb].[dbo].[sysproxies] AS [sPROX]
        ON [sJSTP].[proxy_id] = [sPROX].[proxy_id]
ORDER BY [JobName], [StepNo]
The following is a brief description of each of the fields returned from the above query:

[JobID]: A unique identifier for the SQL Server Agent job (GUID) to which the step(s) belongs.
[JobName]: Name of the SQL Server Agent job.
[StepID]: A unique identifier for the SQL Server Agent Job Step (GUID).
[StepNo]: Sequence number of the step representing the position of the step in the job.
[StepName]: Name of the SQL Server Agent Job Step.
[StepType]: Subsystem/Type of the Job Step like SQL Server Integration Services Package, Transact-SQL Script (T-SQL), ActiveX Script etc.
[RunAs]: Account under which the job step should be run/executed. This will contain a value in the above query output only when run through a proxy.
[Database]: Name of the database in which the command is executed. This applies only when the Step Type is Transact-SQL Script (T-SQL).
[ExecutableCommand]: The actual command which will be executed by the subsystem.
[OnSuccessAction]: Action to be taken by SQL Server Agent when the job step succeeds.
[RetryAttempts]: Number of retry attempts made by SQL Server Agent in case the job step fails.
[RetryInterval (Minutes)]: Time interval in minutes between each retry attempt in case the job step fails and SQL Server Agent tries to re-run it.
[OnFailureAction]: Action to be taken by SQL Server Agent when the job step fails.
SQL Server Agent Job Steps Execution Information

SQL Server Agent stores the history of the execution of each of the job steps in system tables in msdb database.

The following query gives us the details of last/latest execution of the job step. This information can also be found in the Job History/Log File Viewer windows in SSMS.

SELECT
    [sJOB].[job_id] AS [JobID]
    , [sJOB].[name] AS [JobName]
    , [sJSTP].[step_uid] AS [StepID]
    , [sJSTP].[step_id] AS [StepNo]
    , [sJSTP].[step_name] AS [StepName]
    , CASE [sJSTP].[last_run_outcome]
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 5 THEN 'Unknown'
      END AS [LastRunStatus]
    , STUFF(
            STUFF(RIGHT('000000' + CAST([sJSTP].[last_run_duration] AS VARCHAR(6)),  6)
                , 3, 0, ':')
            , 6, 0, ':')
      AS [LastRunDuration (HH:MM:SS)]
    , [sJSTP].[last_run_retries] AS [LastRunRetryAttempts]
    , CASE [sJSTP].[last_run_date]
        WHEN 0 THEN NULL
        ELSE 
            CAST(
                CAST([sJSTP].[last_run_date] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJSTP].[last_run_time] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [LastRunDateTime]
FROM
    [msdb].[dbo].[sysjobsteps] AS [sJSTP]
    INNER JOIN [msdb].[dbo].[sysjobs] AS [sJOB]
        ON [sJSTP].[job_id] = [sJOB].[job_id]
ORDER BY [JobName], [StepNo]
The following is a brief description of each of the fields returned from the above query:

[JobID]: A unique identifier for the SQL Server Agent job (GUID) to which the step(s) belongs.
[JobName]: Name of the SQL Server Agent job.
[StepID]: A unique identifier for the SQL Server Agent Job Step (GUID).
[StepNo]: Sequence number of the step representing the position of the step in the job.
[StepName]: Name of the SQL Server Agent Job Step.
[LastRunStatus]: Status or Outcome of the step execution when the job/step executed last time.
[LastRunDuration (HH:MM:SS)]: Duration of the last run represented in Hours:Minutes:Seconds format.
[LastRunRetryAttempts]: Number of retry attempts made by SQL Server Agent during the last run of the job step.
[LastRunDateTime]: Date and time when the job step was last run.
SQL Server Agent Job Schedule Information

SQL Server allows creating schedules for performing various tasks at a specified date and time. This can be a one time schedule or a recurring schedule with or without an end date. Each schedule can be associated with one or more SQL Server Agent Jobs.

The following query gives us the list of schedules created/available in SQL Server and the details (Occurrence, Recurrence, Frequency, etc.) of each of the schedules.

SELECT 
    [schedule_uid] AS [ScheduleID]
    , [name] AS [ScheduleName]
    , CASE [enabled]
        WHEN 1 THEN 'Yes'
        WHEN 0 THEN 'No'
      END AS [IsEnabled]
    , CASE 
        WHEN [freq_type] = 64 THEN 'Start automatically when SQL Server Agent starts'
        WHEN [freq_type] = 128 THEN 'Start whenever the CPUs become idle'
        WHEN [freq_type] IN (4,8,16,32) THEN 'Recurring'
        WHEN [freq_type] = 1 THEN 'One Time'
      END [ScheduleType]
    , CASE [freq_type]
        WHEN 1 THEN 'One Time'
        WHEN 4 THEN 'Daily'
        WHEN 8 THEN 'Weekly'
        WHEN 16 THEN 'Monthly'
        WHEN 32 THEN 'Monthly - Relative to Frequency Interval'
        WHEN 64 THEN 'Start automatically when SQL Server Agent starts'
        WHEN 128 THEN 'Start whenever the CPUs become idle'
      END [Occurrence]
    , CASE [freq_type]
        WHEN 4 THEN 'Occurs every ' + CAST([freq_interval] AS VARCHAR(3)) + ' day(s)'
        WHEN 8 THEN 'Occurs every ' + CAST([freq_recurrence_factor] AS VARCHAR(3)) 
                    + ' week(s) on '
                    + CASE WHEN [freq_interval] & 1 = 1 THEN 'Sunday' ELSE '' END
                    + CASE WHEN [freq_interval] & 2 = 2 THEN ', Monday' ELSE '' END
                    + CASE WHEN [freq_interval] & 4 = 4 THEN ', Tuesday' ELSE '' END
                    + CASE WHEN [freq_interval] & 8 = 8 THEN ', Wednesday' ELSE '' END
                    + CASE WHEN [freq_interval] & 16 = 16 THEN ', Thursday' ELSE '' END
                    + CASE WHEN [freq_interval] & 32 = 32 THEN ', Friday' ELSE '' END
                    + CASE WHEN [freq_interval] & 64 = 64 THEN ', Saturday' ELSE '' END
        WHEN 16 THEN 'Occurs on Day ' + CAST([freq_interval] AS VARCHAR(3)) 
                     + ' of every '
                     + CAST([freq_recurrence_factor] AS VARCHAR(3)) + ' month(s)'
        WHEN 32 THEN 'Occurs on '
                     + CASE [freq_relative_interval]
                        WHEN 1 THEN 'First'
                        WHEN 2 THEN 'Second'
                        WHEN 4 THEN 'Third'
                        WHEN 8 THEN 'Fourth'
                        WHEN 16 THEN 'Last'
                       END
                     + ' ' 
                     + CASE [freq_interval]
                        WHEN 1 THEN 'Sunday'
                        WHEN 2 THEN 'Monday'
                        WHEN 3 THEN 'Tuesday'
                        WHEN 4 THEN 'Wednesday'
                        WHEN 5 THEN 'Thursday'
                        WHEN 6 THEN 'Friday'
                        WHEN 7 THEN 'Saturday'
                        WHEN 8 THEN 'Day'
                        WHEN 9 THEN 'Weekday'
                        WHEN 10 THEN 'Weekend day'
                       END
                     + ' of every ' + CAST([freq_recurrence_factor] AS VARCHAR(3)) 
                     + ' month(s)'
      END AS [Recurrence]
    , CASE [freq_subday_type]
        WHEN 1 THEN 'Occurs once at ' 
                    + STUFF(
                 STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 2 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Second(s) between ' 
                    + STUFF(
                   STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 4 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Minute(s) between ' 
                    + STUFF(
                   STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 8 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Hour(s) between ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
      END [Frequency]
    , STUFF(
            STUFF(CAST([active_start_date] AS VARCHAR(8)), 5, 0, '-')
                , 8, 0, '-') AS [ScheduleUsageStartDate]
    , STUFF(
            STUFF(CAST([active_end_date] AS VARCHAR(8)), 5, 0, '-')
                , 8, 0, '-') AS [ScheduleUsageEndDate]
    , [date_created] AS [ScheduleCreatedOn]
    , [date_modified] AS [ScheduleLastModifiedOn]
FROM [msdb].[dbo].[sysschedules]
ORDER BY [ScheduleName]



You can use the following query to get the execution history for SSIS Packages between two specific date/time values.

SELECT JobID, JobName, StepID, StepNo, StepName, LastRunStatus, [LastRunDuration (HH:MM:SS)], LastRunRetryAttempts, LastRunDateTime
FROM 
(
 SELECT
  [sJOB].[job_id] AS [JobID]
  , [sJOB].[name] AS [JobName]
  , [sJSTP].[step_uid] AS [StepID]
  , [sJSTP].[step_id] AS [StepNo]
  , [sJSTP].[step_name] AS [StepName]
  , CASE [sJSTP].[last_run_outcome]
   WHEN 0 THEN 'Failed'
   WHEN 1 THEN 'Succeeded'
   WHEN 2 THEN 'Retry'
   WHEN 3 THEN 'Canceled'
   WHEN 5 THEN 'Unknown'
    END AS [LastRunStatus]
  , STUFF(
    STUFF(RIGHT('000000' + CAST([sJSTP].[last_run_duration] AS VARCHAR(6)),  6)
     , 3, 0, ':')
    , 6, 0, ':')
    AS [LastRunDuration (HH:MM:SS)]
  , [sJSTP].[last_run_retries] AS [LastRunRetryAttempts]
  , CASE [sJSTP].[last_run_date]
   WHEN 0 THEN NULL
   ELSE 
    CAST(
     CAST([sJSTP].[last_run_date] AS CHAR(8))
     + ' ' 
     + STUFF(
      STUFF(RIGHT('000000' + CAST([sJSTP].[last_run_time] AS VARCHAR(6)),  6)
       , 3, 0, ':')
      , 6, 0, ':')
     AS DATETIME)
    END AS [LastRunDateTime]
 FROM
  [msdb].[dbo].[sysjobsteps] AS [sJSTP]
  INNER JOIN [msdb].[dbo].[sysjobs] AS [sJOB]
   ON [sJSTP].[job_id] = [sJOB].[job_id]
 WHERE [sJSTP].[subsystem] = 'SSIS'
) Tmp
WHERE [LastRunDateTime] BETWEEN '2012-05-01' AND '2014-05-28'
ORDER BY [JobName], [StepNo]





SELECT

    [sJOB].[job_id] AS [JobID]

    , [sJOB].[name] AS [JobName]

    , [sJSTP].[step_uid] AS [StepID]

    , [sJSTP].[step_id] AS [StepNo]

    , [sJSTP].[step_name] AS [StepName]

    , CASE [sJSTP].[subsystem]

        WHEN 'ActiveScripting' THEN 'ActiveX Script'

        WHEN 'CmdExec' THEN 'Operating system (CmdExec)'

        WHEN 'PowerShell' THEN 'PowerShell'

        WHEN 'Distribution' THEN 'Replication Distributor'

        WHEN 'Merge' THEN 'Replication Merge'

        WHEN 'QueueReader' THEN 'Replication Queue Reader'

        WHEN 'Snapshot' THEN 'Replication Snapshot'

        WHEN 'LogReader' THEN 'Replication Transaction-Log Reader'

        WHEN 'ANALYSISCOMMAND' THEN 'SQL Server Analysis Services Command'

        WHEN 'ANALYSISQUERY' THEN 'SQL Server Analysis Services Query'

        WHEN 'SSIS' THEN 'SQL Server Integration Services Package'

        WHEN 'TSQL' THEN 'Transact-SQL script (T-SQL)'

        ELSE sJSTP.subsystem

      END AS [StepType]

    , [sPROX].[name] AS [RunAs]

    , [sJSTP].[database_name] AS [Database]

    , [sJSTP].[command] AS [ExecutableCommand]

    , CASE [sJSTP].[on_success_action]

        WHEN 1 THEN 'Quit the job reporting success'

        WHEN 2 THEN 'Quit the job reporting failure'

        WHEN 3 THEN 'Go to the next step'

        WHEN 4 THEN 'Go to Step: ' 

                    + QUOTENAME(CAST([sJSTP].[on_success_step_id] AS VARCHAR(3))) 

                    + ' ' 

                    + [sOSSTP].[step_name]

      END AS [OnSuccessAction]

    , [sJSTP].[retry_attempts] AS [RetryAttempts]

    , [sJSTP].[retry_interval] AS [RetryInterval (Minutes)]

    , CASE [sJSTP].[on_fail_action]

        WHEN 1 THEN 'Quit the job reporting success'

        WHEN 2 THEN 'Quit the job reporting failure'

        WHEN 3 THEN 'Go to the next step'

        WHEN 4 THEN 'Go to Step: ' 

                    + QUOTENAME(CAST([sJSTP].[on_fail_step_id] AS VARCHAR(3))) 

                    + ' ' 

                    + [sOFSTP].[step_name]

      END AS [OnFailureAction]

FROM

    [msdb].[dbo].[sysjobsteps] AS [sJSTP]

    INNER JOIN [msdb].[dbo].[sysjobs] AS [sJOB]

        ON [sJSTP].[job_id] = [sJOB].[job_id]

    LEFT JOIN [msdb].[dbo].[sysjobsteps] AS [sOSSTP]

        ON [sJSTP].[job_id] = [sOSSTP].[job_id]

        AND [sJSTP].[on_success_step_id] = [sOSSTP].[step_id]

    LEFT JOIN [msdb].[dbo].[sysjobsteps] AS [sOFSTP]

        ON [sJSTP].[job_id] = [sOFSTP].[job_id]

        AND [sJSTP].[on_fail_step_id] = [sOFSTP].[step_id]

    LEFT JOIN [msdb].[dbo].[sysproxies] AS [sPROX]

        ON [sJSTP].[proxy_id] = [sPROX].[proxy_id]

ORDER BY [JobName], [StepNo]





SELECT 
    [sJOB].[job_id] AS [JobID]
     ,[sJOB].[name] AS [JobName]
    , CASE 
        WHEN [sJOBH].[run_date] IS NULL OR [sJOBH].[run_time] IS NULL THEN NULL
        ELSE CAST(
                CAST([sJOBH].[run_date] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBH].[run_time] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [LastRunDateTime]
    , CASE [sJOBH].[run_status]
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 4 THEN 'Running' -- In Progress
      END AS [LastRunStatus]
    , STUFF(
            STUFF(RIGHT('000000' + CAST([sJOBH].[run_duration] AS VARCHAR(6)),  6)
                , 3, 0, ':')
            , 6, 0, ':') 
        AS [LastRunDuration (HH:MM:SS)]
    , [sJOBH].[message] AS [LastRunStatusMessage]
    , CASE [sJOBSCH].[NextRunDate]
        WHEN 0 THEN NULL
        ELSE CAST(
                CAST([sJOBSCH].[NextRunDate] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBSCH].[NextRunTime] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [NextRunDateTime] INTO #tbl_Output      
      
FROM 
    [msdb].[dbo].[sysjobs] AS [sJOB]
    LEFT JOIN (
                SELECT
                    [job_id]
                    , MAX([next_run_date]) AS [NextRunDate]
                    , MAX([next_run_time]) AS [NextRunTime]
                FROM [msdb].[dbo].[sysjobschedules]
                GROUP BY [job_id]
            ) AS [sJOBSCH]
        ON [sJOB].[job_id] = [sJOBSCH].[job_id]
    LEFT JOIN (
                SELECT 
                      [job_id]
                    , [run_date]
                    , [run_time]
                    , [run_status]
                    , [run_duration]
                    , [message]
                    --, ROW_NUMBER() OVER (
                    --                        PARTITION BY [job_id] 
                    --                        ORDER BY [run_date] DESC, [run_time] DESC
                    --  ) AS RowNumber
                 
                FROM [msdb].[dbo].[sysjobhistory]
                WHERE [step_id] = 0
            ) AS [sJOBH]
        ON [sJOB].[job_id] = [sJOBH].[job_id]
       -- AND [sJOBH].[RowNumber] = 1
ORDER BY [JobName]



SELECT 
       O.[JobName]
      ,O.[LastRunDateTime]
      ,O.[NextRunDateTime]
      ,O.[LastRunDuration (HH:MM:SS)]
      ,O.[LastRunStatusMessage]      
      ,O.[LastRunStatus]
  FROM [dbo].[#tbl_Output] AS O
  
  INNER JOIN (SELECT
        JobName,
        MAX([LastRunDateTime]) AS [LastRunDateTime],
        MAX([NextRunDateTime]) AS [NextRunDateTime]
    FROM [dbo].[#tbl_Output]
GROUP BY JobName) AS D ON O.[JobName] = D.[JobName] AND O.[LastRunDateTime] = D.[LastRunDateTime]
  


****/

use msdb 
SELECT 
 dbo.sysjobs.Name AS 'Job Name'
, '' 'Location'
,'Job Enabled' = CASE dbo.sysjobs.Enabled
WHEN 1 THEN 'Yes'
WHEN 0 THEN 'No'
END,
'Frequency' = CASE dbo.sysschedules.freq_type
WHEN 1 THEN 'Once'
WHEN 4 THEN 'Daily'
WHEN 8 THEN 'Weekly'
WHEN 16 THEN 'Monthly'
WHEN 32 THEN 'Monthly relative'
WHEN 64 THEN 'When SQLServer Agent starts'
END, 
'Start Date' = CASE active_start_date
WHEN 0 THEN null
ELSE
substring(convert(varchar(15),active_start_date),1,4) + '/' + 
substring(convert(varchar(15),active_start_date),5,2) + '/' + 
substring(convert(varchar(15),active_start_date),7,2)
END,
'Start Time' = CASE len(active_start_time)
WHEN 1 THEN cast('00:00:0' + right(active_start_time,2) as char(8))
WHEN 2 THEN cast('00:00:' + right(active_start_time,2) as char(8))
WHEN 3 THEN cast('00:0' 
+ Left(right(active_start_time,3),1)  
+':' + right(active_start_time,2) as char (8))
WHEN 4 THEN cast('00:' 
+ Left(right(active_start_time,4),2)  
+':' + right(active_start_time,2) as char (8))
WHEN 5 THEN cast('0' 
+ Left(right(active_start_time,5),1) 
+':' + Left(right(active_start_time,4),2)  
+':' + right(active_start_time,2) as char (8))
WHEN 6 THEN cast(Left(right(active_start_time,6),2) 
+':' + Left(right(active_start_time,4),2)  
+':' + right(active_start_time,2) as char (8))
END,
-- active_start_time as 'Start Time',
CASE len(run_duration)
WHEN 1 THEN cast('00:00:0'
+ cast(run_duration as char) as char (8))
WHEN 2 THEN cast('00:00:'
+ cast(run_duration as char) as char (8))
WHEN 3 THEN cast('00:0' 
+ Left(right(run_duration,3),1)  
+':' + right(run_duration,2) as char (8))
WHEN 4 THEN cast('00:' 
+ Left(right(run_duration,4),2)  
+':' + right(run_duration,2) as char (8))
WHEN 5 THEN cast('0' 
+ Left(right(run_duration,5),1) 
+':' + Left(right(run_duration,4),2)  
+':' + right(run_duration,2) as char (8))
WHEN 6 THEN cast(Left(right(run_duration,6),2) 
+':' + Left(right(run_duration,4),2)  
+':' + right(run_duration,2) as char (8))
END as 'Max Duration',
    CASE(dbo.sysschedules.freq_subday_interval)
WHEN 0 THEN 'Once'
ELSE cast('Every ' 
+ right(dbo.sysschedules.freq_subday_interval,2) 
+ ' '
+     CASE(dbo.sysschedules.freq_subday_type)
WHEN 1 THEN 'Once'
WHEN 4 THEN 'Minutes'
WHEN 8 THEN 'Hours'
END as char(16))
    END as 'Subday Frequency'--,/**bernard addition**/dbo.sysschedules.*
    /****************************************************/
    ,[schedule_uid] AS [ScheduleID]
    , dbo.sysjobs.[name] AS [ScheduleName]
    , CASE dbo.sysjobs.[enabled]
        WHEN 1 THEN 'Yes'
        WHEN 0 THEN 'No'
      END AS [IsEnabled]
    , CASE 
        WHEN [freq_type] = 64 THEN 'Start automatically when SQL Server Agent starts'
        WHEN [freq_type] = 128 THEN 'Start whenever the CPUs become idle'
        WHEN [freq_type] IN (4,8,16,32) THEN 'Recurring'
        WHEN [freq_type] = 1 THEN 'One Time'
      END [ScheduleType]
    , CASE [freq_type]
        WHEN 1 THEN 'One Time'
        WHEN 4 THEN 'Daily'
        WHEN 8 THEN 'Weekly'
        WHEN 16 THEN 'Monthly'
        WHEN 32 THEN 'Monthly - Relative to Frequency Interval'
        WHEN 64 THEN 'Start automatically when SQL Server Agent starts'
        WHEN 128 THEN 'Start whenever the CPUs become idle'
      END [Occurrence]
    , CASE [freq_type]
        WHEN 4 THEN 'Occurs every ' + CAST([freq_interval] AS VARCHAR(3)) + ' day(s)'
        WHEN 8 THEN 'Occurs every ' + CAST([freq_recurrence_factor] AS VARCHAR(3)) 
                    + ' week(s) on '
                    + CASE WHEN [freq_interval] & 1 = 1 THEN 'Sunday' ELSE '' END
                    + CASE WHEN [freq_interval] & 2 = 2 THEN ', Monday' ELSE '' END
                    + CASE WHEN [freq_interval] & 4 = 4 THEN ', Tuesday' ELSE '' END
                    + CASE WHEN [freq_interval] & 8 = 8 THEN ', Wednesday' ELSE '' END
                    + CASE WHEN [freq_interval] & 16 = 16 THEN ', Thursday' ELSE '' END
                    + CASE WHEN [freq_interval] & 32 = 32 THEN ', Friday' ELSE '' END
                    + CASE WHEN [freq_interval] & 64 = 64 THEN ', Saturday' ELSE '' END
        WHEN 16 THEN 'Occurs on Day ' + CAST([freq_interval] AS VARCHAR(3)) 
                     + ' of every '
                     + CAST([freq_recurrence_factor] AS VARCHAR(3)) + ' month(s)'
        WHEN 32 THEN 'Occurs on '
                     + CASE [freq_relative_interval]
                        WHEN 1 THEN 'First'
                        WHEN 2 THEN 'Second'
                        WHEN 4 THEN 'Third'
                        WHEN 8 THEN 'Fourth'
                        WHEN 16 THEN 'Last'
                       END
                     + ' ' 
                     + CASE [freq_interval]
                        WHEN 1 THEN 'Sunday'
                        WHEN 2 THEN 'Monday'
                        WHEN 3 THEN 'Tuesday'
                        WHEN 4 THEN 'Wednesday'
                        WHEN 5 THEN 'Thursday'
                        WHEN 6 THEN 'Friday'
                        WHEN 7 THEN 'Saturday'
                        WHEN 8 THEN 'Day'
                        WHEN 9 THEN 'Weekday'
                        WHEN 10 THEN 'Weekend day'
                       END
                     + ' of every ' + CAST([freq_recurrence_factor] AS VARCHAR(3)) 
                     + ' month(s)'
      END AS [Recurrence]
    , CASE [freq_subday_type]
        WHEN 1 THEN 'Occurs once at ' 
                    + STUFF(
                 STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 2 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Second(s) between ' 
                    + STUFF(
                   STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 4 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Minute(s) between ' 
                    + STUFF(
                   STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 8 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Hour(s) between ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
      END [Frequency]
    , STUFF(
            STUFF(CAST([active_start_date] AS VARCHAR(8)), 5, 0, '-')
                , 8, 0, '-') AS [ScheduleUsageStartDate]
    , STUFF(
            STUFF(CAST([active_end_date] AS VARCHAR(8)), 5, 0, '-')
                , 8, 0, '-') AS [ScheduleUsageEndDate]
    --, [date_created] AS [ScheduleCreatedOn]
    --, [date_modified] AS [ScheduleLastModifiedOn]
    ,[sDBP].[name] AS [JobOwner]
    , dbo.sysjobs .[description] AS [JobDescription]
    , dbo.sysjobs .category_id AS [category_id]
    /****************************************************/
    
FROM dbo.sysjobs 
LEFT OUTER JOIN dbo.sysjobschedules ON dbo.sysjobs.job_id = dbo.sysjobschedules.job_id
LEFT JOIN [msdb].[sys].[database_principals] AS [sDBP]    ON dbo.sysjobs .[owner_sid] = [sDBP].[sid]
INNER JOIN dbo.sysschedules ON dbo.sysjobschedules.schedule_id = dbo.sysschedules.schedule_id 
LEFT OUTER JOIN (SELECT job_id, max(run_duration) AS run_duration
FROM dbo.sysjobhistory
GROUP BY job_id) Q1
ON dbo.sysjobs.job_id = Q1.job_id
WHERE Next_run_time = 0


UNION


SELECT dbo.sysjobs.Name AS 'Job Name'
, '' 'Location' 
,'Job Enabled' = CASE dbo.sysjobs.Enabled
WHEN 1 THEN 'Yes'
WHEN 0 THEN 'No'
END,
'Frequency' = CASE dbo.sysschedules.freq_type
WHEN 1 THEN 'Once'
WHEN 4 THEN 'Daily'
WHEN 8 THEN 'Weekly'
WHEN 16 THEN 'Monthly'
WHEN 32 THEN 'Monthly relative'
WHEN 64 THEN 'When SQLServer Agent starts'
END, 
'Start Date' = CASE next_run_date
WHEN 0 THEN null
ELSE
substring(convert(varchar(15),next_run_date),1,4) + '/' + 
substring(convert(varchar(15),next_run_date),5,2) + '/' + 
substring(convert(varchar(15),next_run_date),7,2)
END,
'Start Time' = CASE len(next_run_time)
WHEN 1 THEN cast('00:00:0' + right(next_run_time,2) as char(8))
WHEN 2 THEN cast('00:00:' + right(next_run_time,2) as char(8))
WHEN 3 THEN cast('00:0' 
+ Left(right(next_run_time,3),1)  
+':' + right(next_run_time,2) as char (8))
WHEN 4 THEN cast('00:' 
+ Left(right(next_run_time,4),2)  
+':' + right(next_run_time,2) as char (8))
WHEN 5 THEN cast('0' + Left(right(next_run_time,5),1) 
+':' + Left(right(next_run_time,4),2)  
+':' + right(next_run_time,2) as char (8))
WHEN 6 THEN cast(Left(right(next_run_time,6),2) 
+':' + Left(right(next_run_time,4),2)  
+':' + right(next_run_time,2) as char (8))
END,
-- next_run_time as 'Start Time',
CASE len(run_duration)
WHEN 1 THEN cast('00:00:0'
+ cast(run_duration as char) as char (8))
WHEN 2 THEN cast('00:00:'
+ cast(run_duration as char) as char (8))
WHEN 3 THEN cast('00:0' 
+ Left(right(run_duration,3),1)  
+':' + right(run_duration,2) as char (8))
WHEN 4 THEN cast('00:' 
+ Left(right(run_duration,4),2)  
+':' + right(run_duration,2) as char (8))
WHEN 5 THEN cast('0' 
+ Left(right(run_duration,5),1) 
+':' + Left(right(run_duration,4),2)  
+':' + right(run_duration,2) as char (8))
WHEN 6 THEN cast(Left(right(run_duration,6),2) 
+':' + Left(right(run_duration,4),2)  
+':' + right(run_duration,2) as char (8))
END as 'Max Duration',
    CASE(dbo.sysschedules.freq_subday_interval)
WHEN 0 THEN 'Once'
ELSE cast('Every ' 
+ right(dbo.sysschedules.freq_subday_interval,2) 
+ ' '
+     CASE(dbo.sysschedules.freq_subday_type)
WHEN 1 THEN 'Once'
WHEN 4 THEN 'Minutes'
WHEN 8 THEN 'Hours'
END as char(16))
    END as 'Subday Frequency'--,/**bernard addition**/dbo.sysschedules.*
    /*********************************************************************/
    ,[schedule_uid] AS [ScheduleID]
    , dbo.sysjobs.[name] AS [ScheduleName]
    , CASE dbo.sysjobs.[enabled]
        WHEN 1 THEN 'Yes'
        WHEN 0 THEN 'No'
      END AS [IsEnabled]
    , CASE 
        WHEN [freq_type] = 64 THEN 'Start automatically when SQL Server Agent starts'
        WHEN [freq_type] = 128 THEN 'Start whenever the CPUs become idle'
        WHEN [freq_type] IN (4,8,16,32) THEN 'Recurring'
        WHEN [freq_type] = 1 THEN 'One Time'
      END [ScheduleType]
    , CASE [freq_type]
        WHEN 1 THEN 'One Time'
        WHEN 4 THEN 'Daily'
        WHEN 8 THEN 'Weekly'
        WHEN 16 THEN 'Monthly'
        WHEN 32 THEN 'Monthly - Relative to Frequency Interval'
        WHEN 64 THEN 'Start automatically when SQL Server Agent starts'
        WHEN 128 THEN 'Start whenever the CPUs become idle'
      END [Occurrence]
    , CASE [freq_type]
        WHEN 4 THEN 'Occurs every ' + CAST([freq_interval] AS VARCHAR(3)) + ' day(s)'
        WHEN 8 THEN 'Occurs every ' + CAST([freq_recurrence_factor] AS VARCHAR(3)) 
                    + ' week(s) on '
                    + CASE WHEN [freq_interval] & 1 = 1 THEN 'Sunday' ELSE '' END
                    + CASE WHEN [freq_interval] & 2 = 2 THEN ', Monday' ELSE '' END
                    + CASE WHEN [freq_interval] & 4 = 4 THEN ', Tuesday' ELSE '' END
                    + CASE WHEN [freq_interval] & 8 = 8 THEN ', Wednesday' ELSE '' END
                    + CASE WHEN [freq_interval] & 16 = 16 THEN ', Thursday' ELSE '' END
                    + CASE WHEN [freq_interval] & 32 = 32 THEN ', Friday' ELSE '' END
                    + CASE WHEN [freq_interval] & 64 = 64 THEN ', Saturday' ELSE '' END
        WHEN 16 THEN 'Occurs on Day ' + CAST([freq_interval] AS VARCHAR(3)) 
                     + ' of every '
                     + CAST([freq_recurrence_factor] AS VARCHAR(3)) + ' month(s)'
        WHEN 32 THEN 'Occurs on '
                     + CASE [freq_relative_interval]
                        WHEN 1 THEN 'First'
                        WHEN 2 THEN 'Second'
                        WHEN 4 THEN 'Third'
                        WHEN 8 THEN 'Fourth'
                        WHEN 16 THEN 'Last'
                       END
                     + ' ' 
                     + CASE [freq_interval]
                        WHEN 1 THEN 'Sunday'
                        WHEN 2 THEN 'Monday'
                        WHEN 3 THEN 'Tuesday'
                        WHEN 4 THEN 'Wednesday'
                        WHEN 5 THEN 'Thursday'
                        WHEN 6 THEN 'Friday'
                        WHEN 7 THEN 'Saturday'
                        WHEN 8 THEN 'Day'
                        WHEN 9 THEN 'Weekday'
                        WHEN 10 THEN 'Weekend day'
                       END
                     + ' of every ' + CAST([freq_recurrence_factor] AS VARCHAR(3)) 
                     + ' month(s)'
      END AS [Recurrence]
    , CASE [freq_subday_type]
        WHEN 1 THEN 'Occurs once at ' 
                    + STUFF(
                 STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 2 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Second(s) between ' 
                    + STUFF(
                   STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 4 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Minute(s) between ' 
                    + STUFF(
                   STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
        WHEN 8 THEN 'Occurs every ' 
                    + CAST([freq_subday_interval] AS VARCHAR(3)) + ' Hour(s) between ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_start_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
                    + ' & ' 
                    + STUFF(
                    STUFF(RIGHT('000000' + CAST([active_end_time] AS VARCHAR(6)), 6)
                                , 3, 0, ':')
                            , 6, 0, ':')
      END [Frequency]
    , STUFF(
            STUFF(CAST([active_start_date] AS VARCHAR(8)), 5, 0, '-')
                , 8, 0, '-') AS [ScheduleUsageStartDate]
    , STUFF(
            STUFF(CAST([active_end_date] AS VARCHAR(8)), 5, 0, '-')
                , 8, 0, '-') AS [ScheduleUsageEndDate]
    ,[sDBP].[name] AS [JobOwner]
    ,dbo.sysjobs .[description] AS [JobDescription]
    , dbo.sysjobs .category_id AS [category_id]
    --, [date_created] AS [ScheduleCreatedOn]
    --, [date_modified] AS [ScheduleLastModifiedOn]
    /*********************************************************************/
FROM dbo.sysjobs 
LEFT OUTER JOIN dbo.sysjobschedules ON dbo.sysjobs.job_id = dbo.sysjobschedules.job_id
LEFT JOIN [msdb].[sys].[database_principals] AS [sDBP]    ON dbo.sysjobs .[owner_sid] = [sDBP].[sid]
INNER JOIN dbo.sysschedules ON dbo.sysjobschedules.schedule_id = dbo.sysschedules.schedule_id 
LEFT OUTER JOIN (SELECT job_id, max(run_duration) AS run_duration
FROM dbo.sysjobhistory
GROUP BY job_id) Q1
ON dbo.sysjobs.job_id = Q1.job_id
WHERE Next_run_time <> 0
ORDER BY [Start Date],[Start Time]


 --INSERT INTO #owner  
 --JOB OWNER FINDER EXEC dbo.sp_help_job
 
 /****FIND OBJECT DEPENDANCIES
 
 CREATE TABLE #databases(
    database_id int, 
    database_name sysname
);

-- ignore systems databases
INSERT INTO #databases(database_id, database_name)
SELECT database_id, name FROM sys.databases
WHERE database_id > 4;  

DECLARE 
    @database_id int, 
    @database_name sysname, 
    @sql varchar(max);

CREATE TABLE #dependencies(
    referencing_database varchar(max),
    referencing_schema varchar(max),
    referencing_object_name varchar(max),
    referenced_server varchar(max),
    referenced_database varchar(max),
    referenced_schema varchar(max),
    referenced_object_name varchar(max)
);

WHILE (SELECT COUNT(*) FROM #databases) > 0 BEGIN
    SELECT TOP 1 @database_id = database_id, 
                 @database_name = database_name 
    FROM #databases;

    SET @sql = 'INSERT INTO #dependencies select 
        DB_NAME(' + convert(varchar,@database_id) + '), 
        OBJECT_SCHEMA_NAME(referencing_id,' 
            + convert(varchar,@database_id) +'), 
        OBJECT_NAME(referencing_id,' + convert(varchar,@database_id) + '), 
        referenced_server_name,
        ISNULL(referenced_database_name, db_name(' 
             + convert(varchar,@database_id) + ')),
        referenced_schema_name,
        referenced_entity_name
    FROM ' + quotename(@database_name) + '.sys.sql_expression_dependencies';

    EXEC(@sql);

    DELETE FROM #databases WHERE database_id = @database_id;
END;

SET NOCOUNT OFF;

SELECT * FROM #dependencies 

--DROP TABLE #databases 
--		  ,#dependencies 

********/

--RE: CA State Exam - Loan File Request - Wholesale Loans Conversation Logs

--Added sql query in case if we can not open ssis. 

(OCREPL)
SELECT   
act.FolderID,                                
ln.Name AS Loan_Nbr
,e.EntityID
,e.Name 
,e.LoginName
,e.Title
,t2.Description
,act.ActivityID
,act.DateCreated
,act.TypeID
,t.Description tDescription
,act.UserEntityID
,act.Deleted
,act.DateDeleted
,dtl.Element
,dtl.Val
FROM Activities as act
inner join ActivityDetails (nolock) as dtl on act.ActivityID = dtl.ActivityID
inner join Entities  (nolock) as e on act.UserEntityID = e.EntityID
inner join Types (nolock)  as t on act.TypeID = t.TypeID
inner join Types  (nolock) as t2 on e.TypeID = t2.TypeID
inner join LoanNames (nolock)  as ln on act.FolderID = ln.FolderId
WHERE ln.name in ('7001327985')
ORDER BY act.DateCreated desc


SELECT   
CAST(ln.Name AS NVARCHAR(4000)) AS name
, l.LoanNoteID
, l.FolderID
, l.EntityID
, CAST(l.NoteDateTime AS NVARCHAR(29)) AS NoteDateTime , CAST(l.Context AS NVARCHAR(25)) AS Context , CAST(l.Identifier AS NVARCHAR(25)) AS Identifier , CAST(l.Note AS NVARCHAR(4000)) AS Note , CAST(l.Subject AS NVARCHAR(25)) AS Subject FROM OCrepl.dbo.LoanNotes (nolock)  l inner join OCrepl.dbo.LoanNames (nolock)  as ln on l.FolderID = ln.FolderId WHERE ln.name in ('7001327985')



SELECT   
ln.name as name , l.* 
FROM rpt_doc_conditions  (nolock)  l
inner join LoanNames (nolock)  as ln on l.FolderID = ln.FolderId
WHERE ln.name in ('7001327985')


DATA TRAC: (DMD_DATA)


SELECT g.loan_num, tl.translog_id, tl.file_id, tl.actor_id, tl.field, tl.oldval, tl.newval, tl.changdate, ui.last_name + ', ' + ui.first_name AS [user]
FROM dbo.translog AS tl WITH (NOLOCK)
JOIN dbo.userinfo AS ui WITH (NOLOCK) ON tl.actor_id = ui.actor_id
JOIN dbo.gen g WITH (NOLOCK) ON tl.file_id = g.file_id
WHERE g.loan_num IN ('53540589',
'59558980')
ORDER BY 2 desc

SELECT CAST(g.loan_num AS NVARCHAR(15)) AS loan_num
, CAST(n.file_id AS NVARCHAR(5)) AS file_id
, CAST(n.datetime AS NVARCHAR(29)) AS datetime
, CAST(n.group_id AS NVARCHAR(3)) AS group_id
, CAST(n.actor_id AS NVARCHAR(4)) AS actor_id
, CAST(n.note AS NVARCHAR(4000)) AS note
, n.view_link
, n.suppdbf_note
, n.shrd_web
, CAST(ui.last_name + ', ' + ui.first_name AS NVARCHAR(200)) AS [user]
FROM dbo.notes AS n WITH (NOLOCK)
JOIN dbo.userinfo AS ui WITH (NOLOCK) ON n.actor_id = ui.actor_id
JOIN dbo.gen AS g WITH (NOLOCK) ON n.file_id = g.file_id
WHERE g.loan_num IN ('53540589',
'59558980')
ORDER BY 3 desc

SELECT CAST(g.loan_num AS NVARCHAR(15)) AS loan_num
, CAST(uc.file_id AS NVARCHAR(5)) AS file_id
, CAST(uc.prior_to AS NVARCHAR(1)) AS prior_to
, CAST(uc.condition AS NVARCHAR(4000)) AS condition
, CAST(uc.signoff AS NVARCHAR(29)) AS signoff 
, CAST(uc.so_initials AS NVARCHAR(3)) AS so_initials
, uc.cond_no
, uc.view_link
, CAST(uc.responsible AS NVARCHAR(1)) AS responsible
, CAST(uc.received AS NVARCHAR(29)) AS received
, CAST(uc.rec_initials AS NVARCHAR(3)) AS rec_initials
, CAST(ui.first_name + ' ' + ui.last_name AS NVARCHAR(50)) AS underwrtr_name
FROM dbo.gen AS g WITH (NOLOCK)
JOIN dbo.ucond AS uc WITH (NOLOCK) ON g.file_id = uc.file_id
JOIN dbo.und AS u WITH (NOLOCK) ON g.file_id = u.file_id
JOIN dbo.userinfo AS ui WITH (NOLOCK) ON u.underwrtr = ui.employ_id
WHERE g.loan_num IN ('53540589',
'59558980')
ORDER BY 5 desc

